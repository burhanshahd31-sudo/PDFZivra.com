<?php $__env->startSection('title', 'Cloud Storage Hub'); ?>
<?php $__env->startSection('page-title', 'Multi-Provider Cloud Storage & Documents'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid p-0">

    <?php if(session('success')): ?>
        <div class="alert alert-success border-0 rounded-4 shadow-sm mb-4 d-flex align-items-center gap-2">
            <i class="bi bi-check-circle-fill text-success fs-5"></i>
            <span><?php echo e(session('success')); ?></span>
        </div>
    <?php endif; ?>

    <?php if(session('warning')): ?>
        <div class="alert alert-warning border-0 rounded-4 shadow-sm mb-4 d-flex align-items-center gap-2">
            <i class="bi bi-exclamation-triangle-fill text-warning fs-5"></i>
            <span><?php echo e(session('warning')); ?></span>
        </div>
    <?php endif; ?>

    <!-- Storage Usage & Cloud Connectors Overview -->
    <div class="row g-4 mb-4">
        <!-- Storage Quota Widget -->
        <div class="col-lg-5">
            <div class="card card-cust p-4 border shadow-sm h-100">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="badge bg-primary bg-opacity-10 text-primary rounded-pill px-3 py-1.5 fw-bold small">
                        <i class="bi bi-hdd-network-fill me-1"></i> Cloud Quota
                    </span>
                    <strong class="text-dark small"><?php echo e($usedMb); ?> MB / <?php echo e(number_format($storageCapMb)); ?> MB</strong>
                </div>

                <h5 class="fw-bold text-dark mb-2">Secure Cloud Vault Storage</h5>
                <p class="text-muted small mb-3">Permanent encrypted document storage across all connected platforms.</p>

                <div class="progress rounded-pill mb-2" style="height: 10px;">
                    <div class="progress-bar bg-primary progress-bar-striped progress-bar-animated" role="progressbar" style="width: <?php echo e(max(4, $usagePercent)); ?>%;" aria-valuenow="<?php echo e($usagePercent); ?>" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
                <div class="d-flex justify-content-between text-muted small" style="font-size: 0.78rem;">
                    <span><?php echo e($usagePercent); ?>% Utilized</span>
                    <span><?php echo e(number_format($storageCapMb - $usedMb, 1)); ?> MB Available</span>
                </div>
            </div>
        </div>

        <!-- Cloud Providers Integrations -->
        <div class="col-lg-7">
            <div class="card card-cust p-4 border shadow-sm h-100">
                <h6 class="fw-bold text-dark mb-3"><i class="bi bi-clouds me-1 text-primary"></i> Connected Cloud Storage Integrations</h6>
                <div class="row g-2">
                    <!-- Internal Storage -->
                    <div class="col-sm-6">
                        <div class="p-3 bg-light rounded-3 border d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center gap-2">
                                <i class="bi bi-shield-check fs-4 text-success"></i>
                                <div>
                                    <strong class="text-dark d-block small">PDF Master Vault</strong>
                                    <span class="text-success small" style="font-size: 0.7rem;">● Active & Encrypted</span>
                                </div>
                            </div>
                            <span class="badge bg-success bg-opacity-10 text-success rounded-pill px-2 py-1 small">Primary</span>
                        </div>
                    </div>

                    <!-- Google Drive -->
                    <div class="col-sm-6">
                        <div class="p-3 bg-light rounded-3 border d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center gap-2">
                                <i class="bi bi-google fs-4 text-primary"></i>
                                <div>
                                    <strong class="text-dark d-block small">Google Drive</strong>
                                    <span class="<?php echo e($connectedProviders['google_drive'] ? 'text-success' : 'text-muted'); ?> small" style="font-size: 0.7rem;">
                                        <?php echo e($connectedProviders['google_drive'] ? '● Connected' : '○ Not Linked'); ?>

                                    </span>
                                </div>
                            </div>
                            <?php if($connectedProviders['google_drive']): ?>
                                <form action="<?php echo e(route('customer.cloud-storage.disconnect', 'google_drive')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-xs btn-outline-danger rounded-pill">Disconnect</button>
                                </form>
                            <?php else: ?>
                                <form action="<?php echo e(route('customer.cloud-storage.connect', 'google_drive')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-xs btn-primary rounded-pill">Connect</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Dropbox -->
                    <div class="col-sm-6">
                        <div class="p-3 bg-light rounded-3 border d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center gap-2">
                                <i class="bi bi-box-seam fs-4 text-info"></i>
                                <div>
                                    <strong class="text-dark d-block small">Dropbox</strong>
                                    <span class="<?php echo e($connectedProviders['dropbox'] ? 'text-success' : 'text-muted'); ?> small" style="font-size: 0.7rem;">
                                        <?php echo e($connectedProviders['dropbox'] ? '● Connected' : '○ Not Linked'); ?>

                                    </span>
                                </div>
                            </div>
                            <?php if($connectedProviders['dropbox']): ?>
                                <form action="<?php echo e(route('customer.cloud-storage.disconnect', 'dropbox')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-xs btn-outline-danger rounded-pill">Disconnect</button>
                                </form>
                            <?php else: ?>
                                <form action="<?php echo e(route('customer.cloud-storage.connect', 'dropbox')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-xs btn-primary rounded-pill">Connect</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- OneDrive -->
                    <div class="col-sm-6">
                        <div class="p-3 bg-light rounded-3 border d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center gap-2">
                                <i class="bi bi-microsoft fs-4 text-primary"></i>
                                <div>
                                    <strong class="text-dark d-block small">Microsoft OneDrive</strong>
                                    <span class="<?php echo e($connectedProviders['onedrive'] ? 'text-success' : 'text-muted'); ?> small" style="font-size: 0.7rem;">
                                        <?php echo e($connectedProviders['onedrive'] ? '● Connected' : '○ Not Linked'); ?>

                                    </span>
                                </div>
                            </div>
                            <?php if($connectedProviders['onedrive']): ?>
                                <form action="<?php echo e(route('customer.cloud-storage.disconnect', 'onedrive')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-xs btn-outline-danger rounded-pill">Disconnect</button>
                                </form>
                            <?php else: ?>
                                <form action="<?php echo e(route('customer.cloud-storage.connect', 'onedrive')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-xs btn-primary rounded-pill">Connect</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Storage Toolbar & Action Bar -->
    <div class="card card-cust p-3 mb-4 border shadow-sm">
        <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
            <div class="d-flex align-items-center gap-2 flex-wrap">
                <button type="button" class="btn btn-primary rounded-pill px-3 py-1.5 fw-bold btn-sm shadow-sm" data-bs-toggle="modal" data-bs-target="#uploadModal">
                    <i class="bi bi-cloud-arrow-up-fill me-1"></i> Upload to Cloud
                </button>
                <button type="button" class="btn btn-outline-secondary rounded-pill px-3 py-1.5 fw-semibold btn-sm" data-bs-toggle="modal" data-bs-target="#folderModal">
                    <i class="bi bi-folder-plus me-1"></i> New Folder
                </button>
                <div class="dropdown">
                    <button class="btn btn-light border rounded-pill px-3 py-1.5 fw-semibold btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        <i class="bi bi-folder me-1 text-warning"></i> Folder: <?php echo e($folder); ?>

                    </button>
                    <ul class="dropdown-menu shadow-sm">
                        <li><a class="dropdown-item" href="<?php echo e(route('customer.cloud-storage.index', ['folder' => 'all'])); ?>">All Folders</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route('customer.cloud-storage.index', ['folder' => 'Root'])); ?>">Root Folder</a></li>
                        <?php $__currentLoopData = $folders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a class="dropdown-item" href="<?php echo e(route('customer.cloud-storage.index', ['folder' => $f])); ?>"><?php echo e($f); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>

            <!-- Search Form -->
            <form action="<?php echo e(route('customer.cloud-storage.index')); ?>" method="GET" class="d-flex gap-2">
                <input type="hidden" name="folder" value="<?php echo e($folder); ?>">
                <div class="input-group input-group-sm">
                    <input type="text" name="search" value="<?php echo e($search); ?>" class="form-control rounded-pill-start border-secondary-subtle" placeholder="Search stored files...">
                    <button type="submit" class="btn btn-secondary rounded-pill-end px-3"><i class="bi bi-search"></i></button>
                </div>
            </form>
        </div>
    </div>

    <!-- Files Table -->
    <div class="card card-cust border shadow-sm overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4">Document Name</th>
                        <th>Folder</th>
                        <th>Storage Target</th>
                        <th>File Size</th>
                        <th>Uploaded Date</th>
                        <th class="text-end pe-4">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="ps-4">
                                <div class="d-flex align-items-center gap-2">
                                    <i class="bi bi-file-earmark-pdf-fill fs-4 text-danger"></i>
                                    <div>
                                        <strong class="text-dark d-block text-truncate" style="max-width: 320px;"><?php echo e($cf->name); ?></strong>
                                        <span class="text-muted small" style="font-size: 0.72rem;"><?php echo e($cf->mime_type); ?></span>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span class="badge bg-light text-secondary border rounded-pill px-2.5 py-1 small">
                                    <i class="bi bi-folder-fill text-warning me-1"></i> <?php echo e($cf->folder_name); ?>

                                </span>
                            </td>
                            <td>
                                <span class="badge bg-light text-dark border rounded-pill px-2.5 py-1 small text-capitalize">
                                    <?php echo e(str_replace('_', ' ', $cf->provider)); ?>

                                </span>
                            </td>
                            <td><?php echo e($cf->formatted_size); ?></td>
                            <td class="text-muted small"><?php echo e($cf->created_at->format('M d, Y h:i A')); ?></td>
                            <td class="text-end pe-4">
                                <div class="d-inline-flex align-items-center gap-1">
                                    <!-- Tool Action Dropdown -->
                                    <div class="dropdown">
                                        <button class="btn btn-xs btn-primary rounded-pill px-2.5 py-1 dropdown-toggle fw-bold" type="button" data-bs-toggle="dropdown">
                                            <i class="bi bi-tools me-1"></i> Open In
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                                            <li><a class="dropdown-item small" href="<?php echo e(route('tool.show', 'compress-pdf')); ?>"><i class="bi bi-file-zip me-2 text-primary"></i> Compress PDF</a></li>
                                            <li><a class="dropdown-item small" href="<?php echo e(route('tool.show', 'pdf-to-word')); ?>"><i class="bi bi-file-earmark-word me-2 text-info"></i> PDF to Word</a></li>
                                            <li><a class="dropdown-item small" href="<?php echo e(route('tool.show', 'protect-pdf')); ?>"><i class="bi bi-lock me-2 text-warning"></i> Password Protect</a></li>
                                            <li><a class="dropdown-item small" href="<?php echo e(route('tool.show', 'ocr-pdf')); ?>"><i class="bi bi-eye me-2 text-success"></i> Run OCR</a></li>
                                            <li><a class="dropdown-item small" href="<?php echo e(route('customer.ai-assistant')); ?>"><i class="bi bi-robot me-2 text-primary"></i> AI Assistant Chat</a></li>
                                        </ul>
                                    </div>

                                    <?php if($cf->path): ?>
                                        <a href="<?php echo e(asset('storage/' . $cf->path)); ?>" target="_blank" class="btn btn-xs btn-outline-secondary rounded-pill p-1" title="Download">
                                            <i class="bi bi-download"></i>
                                        </a>
                                    <?php endif; ?>

                                    <form action="<?php echo e(route('customer.cloud-storage.destroy', $cf->id)); ?>" method="POST" onsubmit="return confirm('Delete this file from cloud storage?');" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-xs btn-outline-danger rounded-pill p-1" title="Delete">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center py-5">
                                <div class="p-3 rounded-circle bg-light d-inline-block mb-2">
                                    <i class="bi bi-folder2-open fs-2 text-muted"></i>
                                </div>
                                <h6 class="fw-bold text-dark mb-1">No files in this folder</h6>
                                <p class="text-muted small mb-3">Upload your first document to secure cloud storage or create a folder.</p>
                                <button type="button" class="btn btn-sm btn-primary rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#uploadModal">
                                    <i class="bi bi-cloud-arrow-up-fill me-1"></i> Upload File
                                </button>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- Upload Modal -->
<div class="modal fade" id="uploadModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow">
            <form action="<?php echo e(route('customer.cloud-storage.upload')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold">Upload to Cloud Storage</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Choose File (PDF, Word, Excel, Images up to 50MB)</label>
                        <input type="file" name="file" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Destination Folder</label>
                        <select name="folder_name" class="form-select">
                            <option value="Root">Root Folder</option>
                            <?php $__currentLoopData = $folders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($f); ?>"><?php echo e($f); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Target Cloud Provider</label>
                        <select name="provider" class="form-select">
                            <option value="internal">PDF Master Internal Vault (Default)</option>
                            <?php if($connectedProviders['google_drive']): ?>
                                <option value="google_drive">Google Drive</option>
                            <?php endif; ?>
                            <?php if($connectedProviders['dropbox']): ?>
                                <option value="dropbox">Dropbox</option>
                            <?php endif; ?>
                            <?php if($connectedProviders['onedrive']): ?>
                                <option value="onedrive">Microsoft OneDrive</option>
                            <?php endif; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-light rounded-pill" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4 fw-bold">Upload Document</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- New Folder Modal -->
<div class="modal fade" id="folderModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content border-0 rounded-4 shadow">
            <form action="<?php echo e(route('customer.cloud-storage.create-folder')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold">Create Folder</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Folder Name</label>
                        <input type="text" name="folder_name" class="form-control" placeholder="e.g. Invoices 2026" required>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-light rounded-pill" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-3 fw-bold">Create</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.customer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Websites\Dynamic Website\Laravel First Website\PDFMasster\.PDFMaster\resources\views/customer/cloud_storage.blade.php ENDPATH**/ ?>