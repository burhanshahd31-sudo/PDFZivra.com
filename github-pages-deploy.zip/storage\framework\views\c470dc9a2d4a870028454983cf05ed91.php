<?php $__env->startSection('title', 'All PDF Tools — Complete Suite | ' . ($siteName ?? \App\Models\SystemSetting::get('site_name', 'PDF Master')) ); ?>
<?php $__env->startSection('meta_description', 'Choose from our comprehensive selection of 68 PDF tools: Edit, Compress, Merge, Split, Convert to Word/Excel, and Sign.'); ?>

<?php $__env->startSection('content'); ?>
<div class="py-5 bg-white border-bottom">
    <div class="container text-center py-3" style="max-width: 820px;">
        <span class="badge bg-primary bg-opacity-10 text-primary px-3 py-2 rounded-pill fw-bold mb-3">
            <i class="bi bi-stars me-1"></i> <?php echo e($totalToolsCount ?? 68); ?>+ Online Productivity Tools
        </span>
        <h1 class="display-6 fw-bold mb-2 text-dark">All PDF Tools</h1>
        <p class="text-muted mb-4 lead fs-6">Search, filter, or choose from our comprehensive suite of secure, online PDF tools</p>

        <!-- Search Input with Live Filter & Form Submission -->
        <form method="GET" action="<?php echo e(route('tools.index')); ?>" id="toolsSearchForm" class="mb-3">
            <?php if(!empty($selectedCategory) && strtolower($selectedCategory) !== 'all'): ?>
                <input type="hidden" name="category" value="<?php echo e($selectedCategory); ?>">
            <?php endif; ?>
            <div class="input-group input-group-lg shadow-sm border rounded-pill overflow-hidden bg-white p-1">
                <span class="input-group-text bg-transparent border-0 ps-3 pe-2"><i class="bi bi-search text-primary"></i></span>
                <input type="text" 
                       id="toolsSearchInput"
                       name="search" 
                       class="form-control border-0 shadow-none ps-1 fs-6" 
                       placeholder="Search tools instantly (e.g. merge, compress, word, jpg, split, sign)..." 
                       value="<?php echo e($search ?? ''); ?>"
                       autocomplete="off">
                <?php if(!empty($search)): ?>
                    <a href="<?php echo e(route('tools.index', request()->except('search', 'page'))); ?>" class="btn btn-link text-muted pe-2 text-decoration-none d-flex align-items-center" title="Clear Search">
                        <i class="bi bi-x-circle-fill fs-5"></i>
                    </a>
                <?php endif; ?>
                <button type="submit" class="btn btn-pm-blue px-4 rounded-pill">Search</button>
            </div>
        </form>

        <!-- Category Filter Pills Bar (Scrollable on Mobile, Centered on Desktop) -->
        <div class="d-flex gap-2 justify-content-start justify-content-md-center overflow-x-auto py-1 px-1 custom-scrollbar text-nowrap mt-4" id="toolsFilterPillsBar">
            <a href="<?php echo e(route('tools.index', request()->except('category', 'page'))); ?>" 
               class="btn btn-sm category-filter-pill <?php echo e(empty($selectedCategory) || strtolower($selectedCategory) === 'all' ? 'btn-primary text-white fw-bold shadow-sm active' : 'btn-outline-secondary'); ?> rounded-pill px-3 py-1.5 flex-shrink-0"
               data-filter-slug="all">
                <i class="bi bi-grid-fill me-1"></i> All Tools (<?php echo e($totalToolsCount); ?>)
            </a>
            <?php $__currentLoopData = $allCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $isCatActive = (!empty($selectedCategory) && $selectedCategory === $cat->slug);
                    $cToolsCount = $cat->tools_count ?? $cat->tools->count();
                ?>
                <a href="<?php echo e(route('tools.index', array_merge(request()->except('category', 'page'), ['category' => $cat->slug]))); ?>" 
                   class="btn btn-sm category-filter-pill <?php echo e($isCatActive ? 'btn-primary text-white fw-bold shadow-sm active' : 'btn-outline-secondary'); ?> rounded-pill px-3 py-1.5 flex-shrink-0"
                   data-filter-slug="<?php echo e($cat->slug); ?>">
                    <i class="bi <?php echo e($cat->icon ?? 'bi-folder'); ?> me-1"></i> <?php echo e($cat->name); ?>

                    <span class="badge <?php echo e($isCatActive ? 'bg-white text-primary' : 'bg-secondary bg-opacity-25 text-dark'); ?> ms-1" style="font-size: 0.70rem;"><?php echo e($cToolsCount); ?></span>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('forms.index')); ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3 py-1.5 fw-semibold flex-shrink-0">
                <i class="bi bi-file-earmark-text me-1"></i> PDF Forms Center &rarr;
            </a>
        </div>

        <!-- Active Filter Indicator & Reset Bar -->
        <div id="activeFilterBar" class="d-flex align-items-center justify-content-center gap-2 mt-3 flex-wrap small <?php echo e((empty($selectedCategory) || strtolower($selectedCategory) === 'all') && empty($search) ? 'd-none' : ''); ?>">
            <span class="text-muted fw-semibold">Active Filter:</span>
            <span id="activeCatBadge" class="badge bg-primary bg-opacity-10 text-primary px-3 py-1.5 rounded-pill border border-primary border-opacity-25 align-items-center gap-1.5 <?php echo e(empty($selectedCategory) || strtolower($selectedCategory) === 'all' ? 'd-none' : 'd-inline-flex'); ?>">
                <i class="bi bi-folder-fill"></i> Category: <span id="activeCatName"><?php echo e($allCategories->firstWhere('slug', $selectedCategory)?->name ?? $selectedCategory); ?></span>
                <button type="button" id="clearCatFilterBtn" class="btn btn-link p-0 text-primary ms-1" title="Remove Category Filter">
                    <i class="bi bi-x-circle-fill"></i>
                </button>
            </span>
            <span id="activeSearchBadge" class="badge bg-secondary bg-opacity-10 text-secondary px-3 py-1.5 rounded-pill border align-items-center gap-1.5 <?php echo e(empty($search) ? 'd-none' : 'd-inline-flex'); ?>">
                <i class="bi bi-search"></i> "<span id="activeSearchText"><?php echo e($search); ?></span>"
                <button type="button" id="clearSearchFilterBtn" class="btn btn-link p-0 text-secondary ms-1" title="Remove Search Filter">
                    <i class="bi bi-x-circle-fill"></i>
                </button>
            </span>
            <span class="text-muted ms-1">(Found <span id="toolsLiveCount"><?php echo e($totalMatchingTools); ?></span> matching tools)</span>
            <button type="button" id="resetAllFiltersBtn" class="btn btn-sm btn-outline-danger rounded-pill px-2.5 py-0.5 ms-2" style="font-size: 0.75rem;">
                <i class="bi bi-x-lg me-1"></i> Reset All
            </button>
        </div>

        <div id="defaultCatalogStats" class="text-muted small mt-2 <?php echo e((!empty($selectedCategory) && strtolower($selectedCategory) !== 'all') || !empty($search) ? 'd-none' : ''); ?>">
            Showing all <span id="toolsTotalCountDisplay"><?php echo e($totalToolsCount); ?></span> available tools across <?php echo e($allCategories->count()); ?> categories
        </div>
    </div>
</div>

<div class="py-5" style="background-color: #f8fafc; min-height: 550px;">
    <div class="container" id="toolsContainer">

        <!-- Empty Results Message (Hidden by default unless 0 tools match) -->
        <div id="noToolsNotice" class="text-center py-5 <?php echo e(($totalMatchingTools == 0) ? '' : 'd-none'); ?>">
            <div class="p-5 rounded-4 bg-white border shadow-sm d-inline-block text-center" style="max-width: 500px;">
                <div class="p-3 rounded-circle bg-primary bg-opacity-10 text-primary d-inline-flex fs-1 mb-3">
                    <i class="bi bi-search"></i>
                </div>
                <h5 class="fw-bold text-dark mb-2">No Matching Tools Found</h5>
                <p class="text-muted small mb-4">We couldn't find any PDF tools matching your current search or category filter. Try clearing your filters or using different keywords.</p>
                <div class="d-flex justify-content-center gap-2">
                    <button type="button" id="noResultsResetBtn" class="btn btn-pm-blue rounded-pill px-4">
                        <i class="bi bi-grid-fill me-1"></i> Browse All Tools
                    </button>
                    <a href="<?php echo e(route('forms.index')); ?>" class="btn btn-outline-primary rounded-pill px-4">
                        Explore PDF Forms
                    </a>
                </div>
            </div>
        </div>

        <!-- Categories & Tools Grid -->
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mb-5 category-block" id="cat-<?php echo e($category->slug); ?>" data-category-slug="<?php echo e($category->slug); ?>" data-category-name="<?php echo e($category->name); ?>">
                <div class="d-flex align-items-center justify-content-between mb-3 border-bottom pb-2">
                    <h5 class="fw-bold text-dark mb-0 d-flex align-items-center gap-2">
                        <i class="bi <?php echo e($category->icon ?? 'bi-folder'); ?> text-primary"></i>
                        <span><?php echo e($category->name); ?></span>
                    </h5>
                    <div class="d-flex align-items-center gap-2">
                        <span class="badge bg-light text-muted border rounded-pill px-2.5 py-1 category-count-badge">
                            <span class="cat-visible-count"><?php echo e($category->tools->count()); ?></span> tools
                        </span>
                        <a href="<?php echo e(route('tools.category', $category->slug)); ?>" class="small fw-semibold text-primary text-decoration-none ms-2">
                            View Grid &rarr;
                        </a>
                    </div>
                </div>

                <div class="row g-3 category-tools-row">
                    <?php $__currentLoopData = $category->tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-4 tool-card-item" 
                         data-tool-name="<?php echo e(strtolower($tool->name)); ?>" 
                         data-tool-desc="<?php echo e(strtolower($tool->description)); ?>" 
                         data-tool-slug="<?php echo e($tool->slug); ?>"
                         data-category="<?php echo e($category->slug); ?>">
                        <a href="<?php echo e(route('tool.show', $tool->slug)); ?>" class="tool-tile">
                            <div class="tool-tile-icon" style="background-color: <?php echo e($tool->color); ?>;">
                                <i class="bi <?php echo e($tool->icon); ?>"></i>
                            </div>
                            <div class="flex-grow-1 min-w-0">
                                <div class="d-flex align-items-center justify-content-between mb-1">
                                    <h6 class="fw-bold mb-0 text-dark text-truncate tool-title-text"><?php echo e($tool->name); ?></h6>
                                    <?php if($tool->is_pro_only): ?>
                                        <span class="badge bg-warning text-dark px-1.5 py-0.5 ms-2" style="font-size: 0.65rem; font-weight: 700;">PRO</span>
                                    <?php endif; ?>
                                </div>
                                <p class="text-muted small mb-0 line-clamp-2 tool-desc-text" style="font-size: 0.82rem; line-height: 1.45;">
                                    <?php echo e($tool->description); ?>

                                </p>
                            </div>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const searchInput = document.getElementById('toolsSearchInput');
    const pills = document.querySelectorAll('.category-filter-pill');
    const categoryBlocks = document.querySelectorAll('.category-block');
    const liveCountBadge = document.getElementById('toolsLiveCount');
    const noToolsNotice = document.getElementById('noToolsNotice');
    const activeFilterBar = document.getElementById('activeFilterBar');
    const activeCatBadge = document.getElementById('activeCatBadge');
    const activeCatName = document.getElementById('activeCatName');
    const activeSearchBadge = document.getElementById('activeSearchBadge');
    const activeSearchText = document.getElementById('activeSearchText');
    const defaultCatalogStats = document.getElementById('defaultCatalogStats');
    const clearCatFilterBtn = document.getElementById('clearCatFilterBtn');
    const clearSearchFilterBtn = document.getElementById('clearSearchFilterBtn');
    const resetAllFiltersBtn = document.getElementById('resetAllFiltersBtn');
    const noResultsResetBtn = document.getElementById('noResultsResetBtn');
    const searchForm = document.getElementById('toolsSearchForm');

    let currentCategory = '<?php echo e($selectedCategory ?? "all"); ?>'.toLowerCase();
    if (!currentCategory) currentCategory = 'all';

    // Master filter execution function
    function applyFilters() {
        const query = searchInput ? searchInput.value.trim().toLowerCase() : '';
        let totalVisible = 0;

        categoryBlocks.forEach(block => {
            const blockSlug = block.getAttribute('data-category-slug');
            const isCatMatch = (currentCategory === 'all' || blockSlug === currentCategory);

            if (!isCatMatch) {
                block.classList.add('d-none');
                return;
            }

            let catVisibleCount = 0;
            const itemsInBlock = block.querySelectorAll('.tool-card-item');

            itemsInBlock.forEach(item => {
                const name = item.getAttribute('data-tool-name') || '';
                const desc = item.getAttribute('data-tool-desc') || '';
                const slug = item.getAttribute('data-tool-slug') || '';

                if (!query || name.includes(query) || desc.includes(query) || slug.includes(query)) {
                    item.classList.remove('d-none');
                    catVisibleCount++;
                    totalVisible++;
                } else {
                    item.classList.add('d-none');
                }
            });

            const catCountSpan = block.querySelector('.cat-visible-count');
            if (catCountSpan) catCountSpan.textContent = catVisibleCount;

            if (catVisibleCount > 0) {
                block.classList.remove('d-none');
            } else {
                block.classList.add('d-none');
            }
        });

        // Update active badge & counts
        if (liveCountBadge) liveCountBadge.textContent = totalVisible;

        // Update pills active appearance
        pills.forEach(pill => {
            const pSlug = (pill.getAttribute('data-filter-slug') || 'all').toLowerCase();
            const badge = pill.querySelector('.badge');
            if (pSlug === currentCategory) {
                pill.className = 'btn btn-sm category-filter-pill btn-primary text-white fw-bold shadow-sm active rounded-pill px-3 py-1.5';
                if (badge) {
                    badge.className = 'badge bg-white text-primary ms-1';
                }
            } else {
                pill.className = 'btn btn-sm category-filter-pill btn-outline-secondary rounded-pill px-3 py-1.5';
                if (badge) {
                    badge.className = 'badge bg-secondary bg-opacity-25 text-dark ms-1';
                }
            }
        });

        // Update indicators
        const hasCatFilter = (currentCategory !== 'all');
        const hasSearchFilter = (query.length > 0);

        if (hasCatFilter || hasSearchFilter) {
            if (activeFilterBar) activeFilterBar.classList.remove('d-none');
            if (defaultCatalogStats) defaultCatalogStats.classList.add('d-none');
        } else {
            if (activeFilterBar) activeFilterBar.classList.add('d-none');
            if (defaultCatalogStats) defaultCatalogStats.classList.remove('d-none');
        }

        if (activeCatBadge) {
            if (hasCatFilter) {
                activeCatBadge.classList.remove('d-none');
                activeCatBadge.classList.add('d-inline-flex');
                const activePill = document.querySelector(`.category-filter-pill[data-filter-slug="${currentCategory}"]`);
                if (activeCatName && activePill) {
                    // Extract text without badge number
                    const textNode = activePill.childNodes[1] ? activePill.childNodes[1].textContent.trim() : currentCategory;
                    activeCatName.textContent = textNode || currentCategory;
                }
            } else {
                activeCatBadge.classList.add('d-none');
                activeCatBadge.classList.remove('d-inline-flex');
            }
        }

        if (activeSearchBadge) {
            if (hasSearchFilter) {
                activeSearchBadge.classList.remove('d-none');
                activeSearchBadge.classList.add('d-inline-flex');
                if (activeSearchText) activeSearchText.textContent = query;
            } else {
                activeSearchBadge.classList.add('d-none');
                activeSearchBadge.classList.remove('d-inline-flex');
            }
        }

        // Toggle Empty Notice
        if (noToolsNotice) {
            if (totalVisible === 0) {
                noToolsNotice.classList.remove('d-none');
            } else {
                noToolsNotice.classList.add('d-none');
            }
        }

        // Keep form hidden category input in sync
        if (searchForm) {
            let catInput = searchForm.querySelector('input[name="category"]');
            if (!catInput && hasCatFilter) {
                catInput = document.createElement('input');
                catInput.type = 'hidden';
                catInput.name = 'category';
                searchForm.appendChild(catInput);
            }
            if (catInput) {
                if (hasCatFilter) {
                    catInput.value = currentCategory;
                } else {
                    catInput.remove();
                }
            }
        }

        // Update URL state smoothly without reload
        const url = new URL(window.location);
        if (currentCategory && currentCategory !== 'all') {
            url.searchParams.set('category', currentCategory);
        } else {
            url.searchParams.delete('category');
        }
        if (query) {
            url.searchParams.set('search', query);
        } else {
            url.searchParams.delete('search');
        }
        url.searchParams.delete('page');
        window.history.replaceState({}, '', url);
    }

    // Category Pill Click Listeners
    pills.forEach(pill => {
        pill.addEventListener('click', function (e) {
            e.preventDefault();
            const slug = (this.getAttribute('data-filter-slug') || 'all').toLowerCase();
            currentCategory = slug;
            applyFilters();
        });
    });

    // Keystroke Live Search Listener
    if (searchInput) {
        searchInput.addEventListener('input', function () {
            applyFilters();
        });
    }

    // Clear Category Filter Button
    if (clearCatFilterBtn) {
        clearCatFilterBtn.addEventListener('click', function () {
            currentCategory = 'all';
            applyFilters();
        });
    }

    // Clear Search Filter Button
    if (clearSearchFilterBtn) {
        clearSearchFilterBtn.addEventListener('click', function () {
            if (searchInput) searchInput.value = '';
            applyFilters();
        });
    }

    // Reset All Filters Buttons
    function resetAll() {
        currentCategory = 'all';
        if (searchInput) searchInput.value = '';
        applyFilters();
    }

    if (resetAllFiltersBtn) resetAllFiltersBtn.addEventListener('click', resetAll);
    if (noResultsResetBtn) noResultsResetBtn.addEventListener('click', resetAll);

    // Initial Filter Run on page load
    applyFilters();
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Websites\Dynamic Website\Laravel First Website\PDFMasster\.PDFMaster\resources\views/tools/index.blade.php ENDPATH**/ ?>