<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php
        $siteFavicon = \App\Models\SystemSetting::get('site_favicon');
        $siteLogo = \App\Models\SystemSetting::get('site_logo');
        $siteName = \App\Models\SystemSetting::get('site_name', 'PDF Master');
        $ogImg = \App\Models\SystemSetting::get('og_image');
        $ogImgUrl = $ogImg ? asset('storage/' . $ogImg) : asset('storage/payment/default_qr.png');
    ?>

    <title><?php echo $__env->yieldContent('title', \App\Models\SystemSetting::get('meta_title', $siteName . ' — ' . \App\Models\SystemSetting::get('site_tagline', 'Everything You Need to Work With PDFs'))); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description', \App\Models\SystemSetting::get('meta_description', 'Free online PDF tools: Merge, Split, Compress, Convert to Word/Excel, Sign, Protect and Fill Official Government Forms online with ' . $siteName . '.')); ?>">
    <meta name="keywords" content="<?php echo $__env->yieldContent('meta_keywords', \App\Models\SystemSetting::get('meta_keywords', 'pdf editor, merge pdf, split pdf, convert pdf, free pdf tools, 100% free')); ?>">
    <meta name="author" content="<?php echo e(\App\Models\SystemSetting::get('meta_author', $siteName . ' Team')); ?>">
    <link rel="canonical" href="<?php echo e(url()->current()); ?>">
    <meta name="robots" content="<?php echo e(\App\Models\SystemSetting::get('seo_robots', 'index, follow')); ?>">

    <!-- Google & Bing Search Verification -->
    <?php if($gVerify = \App\Models\SystemSetting::get('google_site_verification')): ?>
        <meta name="google-site-verification" content="<?php echo e($gVerify); ?>">
    <?php endif; ?>
    <?php if($bVerify = \App\Models\SystemSetting::get('bing_site_verification')): ?>
        <meta name="msvalidate.01" content="<?php echo e($bVerify); ?>">
    <?php endif; ?>

    <!-- Dynamic Favicon -->
    <?php if($siteFavicon): ?>
        <link rel="icon" type="image/x-icon" href="<?php echo e(asset('storage/' . $siteFavicon)); ?>">
        <link rel="shortcut icon" href="<?php echo e(asset('storage/' . $siteFavicon)); ?>">
        <link rel="apple-touch-icon" href="<?php echo e(asset('storage/' . $siteFavicon)); ?>">
    <?php else: ?>
        <link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>">
    <?php endif; ?>

    <!-- Open Graph / Facebook & WhatsApp Share Preview -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo e(url()->current()); ?>">
    <meta property="og:title" content="<?php echo $__env->yieldContent('title', \App\Models\SystemSetting::get('meta_title', 'PDF Master — Everything You Need to Work With PDFs')); ?>">
    <meta property="og:description" content="<?php echo $__env->yieldContent('meta_description', \App\Models\SystemSetting::get('meta_description', 'Free online PDF tools: Merge, Split, Compress, Convert to Word/Excel, Sign, Protect and Fill Official Government Forms online with PDF Master.')); ?>">
    <meta property="og:image" content="<?php echo e($ogImgUrl); ?>">
    <meta property="og:site_name" content="<?php echo e($siteName); ?>">

    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:url" content="<?php echo e(url()->current()); ?>">
    <meta name="twitter:title" content="<?php echo $__env->yieldContent('title', \App\Models\SystemSetting::get('meta_title', 'PDF Master — Everything You Need to Work With PDFs')); ?>">
    <meta name="twitter:description" content="<?php echo $__env->yieldContent('meta_description', \App\Models\SystemSetting::get('meta_description', 'Free online PDF tools: Merge, Split, Compress, Convert to Word/Excel, Sign, Protect and Fill Official Government Forms online with PDF Master.')); ?>">
    <meta name="twitter:image" content="<?php echo e($ogImgUrl); ?>">

    <!-- Schema.org Structured Data for Google #1 Ranking -->
    <?php if(\App\Models\SystemSetting::get('schema_org_enabled', true)): ?>
    <script type="application/ld+json">
    <?php echo json_encode([
        '<?php $__contextArgs = [];
if (context()->has($__contextArgs[0])) :
if (isset($value)) { $__contextPrevious[] = $value; }
$value = context()->get($__contextArgs[0]); ?>' => 'https://schema.org',
        '@graph' => [
            [
                '@type' => 'WebSite',
                '@id' => url('/') . '/#website',
                'url' => url('/'),
                'name' => $siteName,
                'description' => \App\Models\SystemSetting::get('meta_description', 'All-in-one PDF SaaS Platform'),
                'potentialAction' => [[
                    '@type' => 'SearchAction',
                    'target' => [
                        '@type' => 'EntryPoint',
                        'urlTemplate' => url('/tools') . '?search={search_term_string}',
                    ],
                    'query-input' => 'required name=search_term_string',
                ]],
            ],
            [
                '@type' => 'SoftwareApplication',
                'name' => $siteName,
                'operatingSystem' => 'All',
                'applicationCategory' => 'BusinessApplication',
                'offers' => [
                    '@type' => 'Offer',
                    'price' => '0.00',
                    'priceCurrency' => 'USD',
                ],
            ],
        ],
    ], JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT); ?>

    </script>
    <?php endif; ?>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Bootstrap 5 CSS & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

    <!-- Laravel Vite Application Styles & Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <style>
        :root {
            --pm-primary: #1d4ed8;
            --pm-primary-hover: #1e40af;
            --pm-accent: #0284c7;
            --pm-bg-body: #f8fafc;
            --pm-card-bg: #ffffff;
            --pm-border: #e2e8f0;
            --pm-text-heading: #0f172a;
            --pm-text-body: #475569;
        }

        [data-bs-theme="dark"] {
            --pm-bg-body: #090d16;
            --pm-card-bg: #111827;
            --pm-border: #1f2937;
            --pm-text-heading: #f8fafc;
            --pm-text-body: #94a3b8;
        }

        html, body {
            overflow-x: hidden !important;
            max-width: 100vw !important;
            width: 100%;
            margin: 0;
            padding: 0;
            position: relative;
        }

        *, *::before, *::after {
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--pm-bg-body);
            color: var(--pm-text-body);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Ultra-Premium Glassmorphism SaaS Navbar */
        /* Luxury Modern SaaS Header */
        .pm-navbar {
            background: rgba(255, 255, 255, 0.88);
            backdrop-filter: blur(16px) saturate(180%);
            -webkit-backdrop-filter: blur(16px) saturate(180%);
            border-bottom: 1px solid rgba(226, 232, 240, 0.8);
            padding: 0.65rem 0;
            position: sticky;
            top: 0;
            z-index: 1050;
            width: 100%;
            max-width: 100vw;
            box-sizing: border-box;
            transition: all 0.25s ease;
            box-shadow: 0 2px 14px rgba(15, 23, 42, 0.03);
        }

        [data-bs-theme="dark"] .pm-navbar {
            background: rgba(15, 23, 42, 0.92);
            border-bottom: 1px solid rgba(30, 41, 59, 0.85);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.35);
        }

        /* Brand Logo */
        .pm-brand {
            display: inline-flex;
            align-items: center;
            gap: 0.6rem;
            text-decoration: none !important;
            white-space: nowrap !important;
            flex-shrink: 0;
            user-select: none;
        }

        .pm-brand-icon {
            width: 36px;
            height: 36px;
            border-radius: 9px;
            background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #ffffff;
            font-size: 1.15rem;
            box-shadow: 0 4px 14px rgba(37, 99, 235, 0.28);
            transition: all 0.25s ease;
            flex-shrink: 0;
        }

        .pm-brand:hover .pm-brand-icon {
            transform: scale(1.05);
            box-shadow: 0 6px 18px rgba(37, 99, 235, 0.38);
        }

        .pm-brand-title {
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-size: 1.25rem;
            font-weight: 800;
            letter-spacing: -0.03em;
            color: #0f172a;
            white-space: nowrap !important;
            display: inline-flex;
            align-items: center;
            line-height: 1;
        }

        [data-bs-theme="dark"] .pm-brand-title {
            color: #f8fafc;
        }

        .pm-brand-title .brand-accent {
            color: #2563eb;
            margin-left: 1px;
        }

        [data-bs-theme="dark"] .pm-brand-title .brand-accent {
            color: #38bdf8;
        }

        /* Modern Nav Links (Clean, Spacious, No Awkward Capsules) */
        .pm-nav-list {
            display: flex;
            align-items: center;
            gap: 0.15rem;
            margin: 0;
            padding: 0;
            list-style: none;
        }

        .pm-nav-link, .nav-link-custom {
            font-weight: 600;
            font-size: 0.88rem;
            color: #475569 !important;
            padding: 0.38rem 0.65rem !important;
            border-radius: 8px;
            text-decoration: none !important;
            transition: all 0.18s ease;
            white-space: nowrap !important;
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
            position: relative;
        }

        @media (min-width: 1400px) {
            .pm-nav-list {
                gap: 0.25rem;
            }
            .pm-nav-link, .nav-link-custom {
                font-size: 0.91rem;
                padding: 0.42rem 0.75rem !important;
            }
        }

        [data-bs-theme="dark"] .pm-nav-link, 
        [data-bs-theme="dark"] .nav-link-custom {
            color: #94a3b8 !important;
        }

        .pm-nav-link:hover, .nav-link-custom:hover {
            color: #2563eb !important;
            background: rgba(37, 99, 235, 0.06);
        }

        [data-bs-theme="dark"] .pm-nav-link:hover,
        [data-bs-theme="dark"] .nav-link-custom:hover {
            color: #38bdf8 !important;
            background: rgba(56, 189, 248, 0.1);
        }

        .pm-nav-link.active, .nav-link-custom.active {
            color: #2563eb !important;
            background: rgba(37, 99, 235, 0.08);
            font-weight: 700;
        }

        [data-bs-theme="dark"] .pm-nav-link.active,
        [data-bs-theme="dark"] .nav-link-custom.active {
            color: #38bdf8 !important;
            background: rgba(56, 189, 248, 0.15);
        }

        /* Tools Dropdown Menu */
        .pm-tools-dropdown-menu {
            min-width: 480px;
            padding: 1.25rem;
            border-radius: 16px;
            border: 1px solid rgba(226, 232, 240, 0.8);
            box-shadow: 0 20px 45px -10px rgba(15, 23, 42, 0.14);
            margin-top: 0.65rem !important;
        }

        [data-bs-theme="dark"] .pm-tools-dropdown-menu {
            background: #111827;
            border-color: #1f2937;
            box-shadow: 0 20px 45px -10px rgba(0, 0, 0, 0.5);
        }

        .pm-dropdown-item-tool {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.6rem 0.75rem;
            border-radius: 10px;
            text-decoration: none !important;
            color: #1e293b;
            transition: all 0.18s ease;
        }

        [data-bs-theme="dark"] .pm-dropdown-item-tool {
            color: #f1f5f9;
        }

        .pm-dropdown-item-tool:hover {
            background: #f1f5f9;
            transform: translateX(3px);
            color: #2563eb;
        }

        [data-bs-theme="dark"] .pm-dropdown-item-tool:hover {
            background: #1e293b;
            color: #38bdf8;
        }

        .pm-dropdown-tool-icon {
            width: 32px;
            height: 32px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 0.95rem;
            flex-shrink: 0;
        }

        /* Right Actions Toolbar */
        .pm-header-actions {
            display: flex;
            align-items: center;
            gap: 0.45rem;
            flex-shrink: 0;
        }

        /* Luxury Search Box — Fully Contained & Mathematically Centered */
        .pm-header-search-form {
            display: flex;
            align-items: center;
            margin: 0;
        }

        .pm-search-box {
            position: relative;
            display: flex;
            align-items: center;
            width: 155px;
            height: 36px;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 9px;
            transition: all 0.22s ease;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.03);
            overflow: hidden;
        }

        [data-bs-theme="dark"] .pm-search-box {
            background: #1e293b;
            border-color: #334155;
        }

        .pm-search-box:focus-within {
            background: #ffffff;
            width: 200px;
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.12);
        }

        [data-bs-theme="dark"] .pm-search-box:focus-within {
            background: #0f172a;
            border-color: #38bdf8;
            box-shadow: 0 0 0 3px rgba(56, 189, 248, 0.15);
        }

        @media (min-width: 1400px) {
            .pm-header-actions {
                gap: 0.6rem;
            }
            .pm-search-box {
                width: 195px;
                height: 38px;
            }
            .pm-search-box:focus-within {
                width: 235px;
            }
        }

        @media (max-width: 1320px) {
            .pm-header-search-form {
                display: none !important;
            }
        }

        .pm-search-icon {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 0.88rem;
            color: #94a3b8;
            pointer-events: none;
            line-height: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 2;
            transition: color 0.2s ease;
        }

        .pm-search-box:focus-within .pm-search-icon {
            color: #2563eb;
        }

        [data-bs-theme="dark"] .pm-search-box:focus-within .pm-search-icon {
            color: #38bdf8;
        }

        .pm-search-input {
            width: 100%;
            height: 100%;
            padding: 0 12px 0 36px !important;
            border: none !important;
            outline: none !important;
            background: transparent !important;
            font-size: 0.85rem !important;
            color: #1e293b !important;
            font-weight: 500 !important;
            box-shadow: none !important;
        }

        [data-bs-theme="dark"] .pm-search-input {
            color: #f1f5f9 !important;
        }

        .pm-search-input::placeholder {
            color: #94a3b8 !important;
            font-weight: 400;
        }

        /* Mobile Hamburger Button */
        .pm-mobile-btn {
            width: 38px;
            height: 38px;
            border-radius: 10px;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            color: #475569;
            transition: all 0.2s ease;
            flex-shrink: 0;
            padding: 0;
        }

        .pm-mobile-btn:hover {
            background: #f1f5f9;
            color: #2563eb;
            border-color: #cbd5e1;
        }

        [data-bs-theme="dark"] .pm-mobile-btn {
            background: #1e293b;
            border-color: #334155;
            color: #f1f5f9;
        }

        /* User Profile Button */
        .pm-user-btn {
            height: 38px;
            padding: 0 0.85rem;
            border-radius: 10px;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            color: #1e293b;
            font-weight: 600;
            font-size: 0.88rem;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            text-decoration: none !important;
            transition: all 0.2s ease;
            white-space: nowrap !important;
            flex-shrink: 0;
        }

        [data-bs-theme="dark"] .pm-user-btn {
            background: #1e293b;
            border-color: #334155;
            color: #f1f5f9;
        }

        .pm-user-btn:hover {
            background: #f1f5f9;
            border-color: #cbd5e1;
            color: #2563eb;
        }

        [data-bs-theme="dark"] .pm-user-btn:hover {
            background: #334155;
            border-color: #475569;
            color: #38bdf8;
        }

        .pm-user-avatar {
            width: 24px;
            height: 24px;
            border-radius: 6px;
            background: linear-gradient(135deg, #2563eb, #1d4ed8);
            color: #ffffff;
            font-size: 0.72rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        /* Modern Login Button */
        .btn-pm-login {
            height: 36px;
            padding: 0 0.85rem;
            border-radius: 9px;
            border: 1px solid #e2e8f0;
            background: #ffffff;
            color: #334155 !important;
            font-weight: 600;
            font-size: 0.84rem;
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            text-decoration: none !important;
            transition: all 0.2s ease;
            white-space: nowrap !important;
            flex-shrink: 0;
        }

        .btn-pm-login:hover {
            border-color: #2563eb;
            color: #2563eb !important;
            background: rgba(37, 99, 235, 0.04);
            transform: translateY(-1px);
        }

        [data-bs-theme="dark"] .btn-pm-login {
            background: #1e293b;
            border-color: #334155;
            color: #cbd5e1 !important;
        }

        [data-bs-theme="dark"] .btn-pm-login:hover {
            border-color: #38bdf8;
            color: #38bdf8 !important;
            background: rgba(56, 189, 248, 0.08);
        }

        /* Primary SaaS CTA Button */
        .btn-pm-cta {
            height: 36px;
            padding: 0 0.95rem;
            border-radius: 9px;
            background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
            color: #ffffff !important;
            font-weight: 600;
            font-size: 0.84rem;
            border: none;
            box-shadow: 0 4px 14px rgba(37, 99, 235, 0.28);
            display: inline-flex;
            align-items: center;
            gap: 0.38rem;
            text-decoration: none !important;
            transition: all 0.2s ease;
            white-space: nowrap !important;
            flex-shrink: 0;
        }

        .btn-pm-cta:hover {
            transform: translateY(-1px);
            box-shadow: 0 6px 18px rgba(37, 99, 235, 0.4);
            background: linear-gradient(135deg, #1d4ed8 0%, #1e40af 100%);
        }

        @media (min-width: 1400px) {
            .btn-pm-login {
                height: 38px;
                padding: 0 1rem;
                font-size: 0.88rem;
            }
            .btn-pm-cta {
                height: 38px;
                padding: 0 1.15rem;
                font-size: 0.88rem;
            }
        }

        /* Primary Buttons */
        .btn-pm-blue {
            background: #2563eb;
            color: #ffffff !important;
            border: none;
            font-weight: 600;
            border-radius: 9999px;
            padding: 0.5rem 1.35rem;
            transition: all 0.2s ease;
        }

        .btn-pm-blue:hover {
            background: #1d4ed8;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3);
        }

        /* Global Link Reset for Cards */
        a, a:hover, a:focus {
            text-decoration: none;
        }

        .tool-card, .tool-tile, .card-saas {
            text-decoration: none !important;
            color: inherit !important;
        }

        .tool-card *, .tool-tile *, .card-saas * {
            text-decoration: none !important;
        }

        /* Card Styling Matching Image */
        .card-saas {
            background: var(--pm-card-bg);
            border: 1px solid var(--pm-border);
            border-radius: 14px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.02);
            transition: all 0.2s ease;
        }

        .card-saas:hover {
            box-shadow: 0 8px 24px rgba(0,0,0,0.06);
        }

        /* Tool Grid Card (Catalog / Horizontal Tiles) */
        .tool-tile {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 14px;
            padding: 1.25rem;
            display: flex;
            align-items: flex-start;
            gap: 1rem;
            text-decoration: none !important;
            color: inherit !important;
            transition: all 0.2s ease;
            height: 100%;
            box-shadow: 0 1px 3px rgba(0,0,0,0.02);
        }

        [data-bs-theme="dark"] .tool-tile {
            background: #111827;
            border-color: #1f2937;
        }

        .tool-tile:hover {
            border-color: #93c5fd;
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(37, 99, 235, 0.08);
            color: inherit !important;
        }

        .tool-tile-icon {
            width: 46px;
            height: 46px;
            min-width: 46px;
            min-height: 46px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.35rem;
            color: #fff !important;
            flex-shrink: 0;
            box-shadow: 0 4px 10px rgba(0,0,0,0.06);
            transition: transform 0.2s ease;
        }

        .tool-tile:hover .tool-tile-icon {
            transform: scale(1.08);
        }

        /* Tool Card — High-end SaaS Grid Card (Category pages & Featured Tools) */
        .tool-card {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 16px;
            padding: 1.5rem;
            display: flex;
            flex-direction: column;
            text-decoration: none !important;
            color: #0f172a !important;
            height: 100%;
            transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.03);
            position: relative;
        }

        [data-bs-theme="dark"] .tool-card {
            background: #111827;
            border-color: #1f2937;
            color: #f1f5f9 !important;
        }

        .tool-card:hover {
            border-color: #3b82f6;
            transform: translateY(-4px);
            box-shadow: 0 14px 30px -8px rgba(15, 23, 42, 0.12), 0 4px 12px -2px rgba(37, 99, 235, 0.08);
            color: #0f172a !important;
            text-decoration: none !important;
        }

        .tool-card-icon {
            width: 48px;
            height: 48px;
            min-width: 48px;
            min-height: 48px;
            border-radius: 12px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 1.4rem;
            color: #ffffff !important;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            transition: transform 0.25s ease;
            flex-shrink: 0;
            margin-bottom: 1rem;
        }

        .tool-card:hover .tool-card-icon {
            transform: scale(1.08) rotate(3deg);
        }

        .tool-card-title {
            font-size: 1.05rem;
            font-weight: 700;
            color: #0f172a !important;
            margin-bottom: 0.4rem;
            text-decoration: none !important;
            transition: color 0.2s ease;
        }

        [data-bs-theme="dark"] .tool-card-title {
            color: #f8fafc !important;
        }

        .tool-card:hover .tool-card-title {
            color: #2563eb !important;
        }

        .tool-card-desc {
            color: #64748b !important;
            font-size: 0.84rem;
            line-height: 1.5;
            margin-bottom: 1.25rem;
            min-height: 40px;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-decoration: none !important;
        }

        [data-bs-theme="dark"] .tool-card-desc {
            color: #94a3b8 !important;
        }

        .tool-card-footer {
            margin-top: auto;
            padding-top: 0.85rem;
            border-top: 1px solid #f1f5f9;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        [data-bs-theme="dark"] .tool-card-footer {
            border-color: #1f2937;
        }

        .tool-card-open {
            color: #2563eb !important;
            font-weight: 600;
            font-size: 0.85rem;
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            text-decoration: none !important;
            transition: all 0.2s ease;
        }

        .tool-card:hover .tool-card-open {
            color: #1d4ed8 !important;
            transform: translateX(4px);
        }

        /* High-End, High-Contrast SaaS Footer */
        .pm-footer-dark {
            background: linear-gradient(180deg, #090e1f 0%, #050813 100%);
            color: #e2e8f0;
            padding: 4.5rem 0 2rem;
            margin-top: auto;
            border-top: 1px solid rgba(255, 255, 255, 0.08);
            font-size: 0.90rem;
        }

        .pm-footer-dark h6 {
            color: #ffffff !important;
            font-weight: 700;
            font-size: 1rem;
            letter-spacing: 0.02em;
            margin-bottom: 1.25rem;
            position: relative;
            display: inline-block;
        }

        .pm-footer-dark h6::after {
            content: '';
            position: absolute;
            bottom: -6px;
            left: 0;
            width: 26px;
            height: 2px;
            background: #2563eb;
            border-radius: 2px;
        }

        .pm-footer-dark a:not(.footer-social-btn) {
            color: #cbd5e1 !important;
            text-decoration: none;
            margin-bottom: 0.55rem;
            display: inline-block;
            transition: all 0.2s ease;
            font-weight: 400;
        }

        .pm-footer-dark a:not(.footer-social-btn):hover {
            color: #38bdf8 !important;
            transform: translateX(4px);
        }

        .pm-footer-desc {
            color: #94a3b8 !important;
            font-size: 0.88rem;
            line-height: 1.6;
        }

        /* State-of-the-Art Luxury Social Media Badges */
        .pm-social-list {
            display: flex;
            align-items: center;
            gap: 0.65rem;
            flex-wrap: wrap;
            margin-top: 0.25rem;
        }

        .footer-social-btn {
            width: 44px !important;
            height: 44px !important;
            min-width: 44px !important;
            min-height: 44px !important;
            border-radius: 12px !important;
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            text-align: center !important;
            text-decoration: none !important;
            line-height: 1 !important;
            margin: 0 !important;
            padding: 0 !important;
            border: 1px solid rgba(255, 255, 255, 0.14) !important;
            background: rgba(255, 255, 255, 0.05) !important;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25) !important;
            backdrop-filter: blur(8px);
            transition: all 0.28s cubic-bezier(0.34, 1.56, 0.64, 1) !important;
            position: relative;
            overflow: hidden;
            vertical-align: middle !important;
        }

        .footer-social-btn i {
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            width: 100% !important;
            height: 100% !important;
            font-size: 1.25rem !important;
            line-height: 1 !important;
            margin: 0 !important;
            padding: 0 !important;
            transition: transform 0.25s ease !important;
        }

        .footer-social-btn i::before {
            line-height: 1 !important;
            vertical-align: 0 !important;
            display: inline-block !important;
        }

        .footer-social-btn:hover i {
            transform: scale(1.18) !important;
        }

        /* Resting platform brand tint for instant recognition */
        .footer-social-btn.btn-fb {
            color: #60a5fa !important;
            background: rgba(37, 99, 235, 0.12) !important;
            border-color: rgba(59, 130, 246, 0.25) !important;
        }
        .footer-social-btn.btn-tw {
            color: #f1f5f9 !important;
            background: rgba(255, 255, 255, 0.08) !important;
            border-color: rgba(255, 255, 255, 0.22) !important;
        }
        .footer-social-btn.btn-ig {
            color: #f472b6 !important;
            background: rgba(236, 72, 153, 0.12) !important;
            border-color: rgba(236, 72, 153, 0.25) !important;
        }
        .footer-social-btn.btn-li {
            color: #38bdf8 !important;
            background: rgba(14, 165, 233, 0.12) !important;
            border-color: rgba(14, 165, 233, 0.25) !important;
        }
        .footer-social-btn.btn-yt {
            color: #f87171 !important;
            background: rgba(239, 68, 68, 0.12) !important;
            border-color: rgba(239, 68, 68, 0.25) !important;
        }
        .footer-social-btn.btn-wa {
            color: #4ade80 !important;
            background: rgba(34, 197, 94, 0.12) !important;
            border-color: rgba(34, 197, 94, 0.25) !important;
        }
        .footer-social-btn.btn-tg {
            color: #38bdf8 !important;
            background: rgba(6, 182, 212, 0.12) !important;
            border-color: rgba(6, 182, 212, 0.25) !important;
        }
        .footer-social-btn.btn-gh {
            color: #e2e8f0 !important;
            background: rgba(255, 255, 255, 0.08) !important;
            border-color: rgba(255, 255, 255, 0.22) !important;
        }

        /* Vibrant Brand Glow on Hover */
        .footer-social-btn.btn-fb:hover {
            background: linear-gradient(135deg, #1877f2 0%, #0d65d9 100%) !important;
            border-color: #1877f2 !important;
            color: #ffffff !important;
            box-shadow: 0 8px 24px rgba(24, 119, 242, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.35) !important;
            transform: translateY(-4px) scale(1.08) !important;
        }

        .footer-social-btn.btn-tw:hover {
            background: linear-gradient(135deg, #1e293b 0%, #000000 100%) !important;
            border-color: rgba(255, 255, 255, 0.45) !important;
            color: #ffffff !important;
            box-shadow: 0 8px 24px rgba(255, 255, 255, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.35) !important;
            transform: translateY(-4px) scale(1.08) !important;
        }

        .footer-social-btn.btn-ig:hover {
            background: linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%) !important;
            border-color: transparent !important;
            color: #ffffff !important;
            box-shadow: 0 8px 24px rgba(220, 39, 67, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.35) !important;
            transform: translateY(-4px) scale(1.08) !important;
        }

        .footer-social-btn.btn-li:hover {
            background: linear-gradient(135deg, #0a66c2 0%, #004182 100%) !important;
            border-color: #0a66c2 !important;
            color: #ffffff !important;
            box-shadow: 0 8px 24px rgba(10, 102, 194, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.35) !important;
            transform: translateY(-4px) scale(1.08) !important;
        }

        .footer-social-btn.btn-yt:hover {
            background: linear-gradient(135deg, #ff0000 0%, #b91c1c 100%) !important;
            border-color: #ff0000 !important;
            color: #ffffff !important;
            box-shadow: 0 8px 24px rgba(255, 0, 0, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.35) !important;
            transform: translateY(-4px) scale(1.08) !important;
        }

        .footer-social-btn.btn-wa:hover {
            background: linear-gradient(135deg, #25d366 0%, #059669 100%) !important;
            border-color: #25d366 !important;
            color: #ffffff !important;
            box-shadow: 0 8px 24px rgba(37, 211, 102, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.35) !important;
            transform: translateY(-4px) scale(1.08) !important;
        }

        .footer-social-btn.btn-tg:hover {
            background: linear-gradient(135deg, #229ed9 0%, #0284c7 100%) !important;
            border-color: #229ed9 !important;
            color: #ffffff !important;
            box-shadow: 0 8px 24px rgba(34, 158, 217, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.35) !important;
            transform: translateY(-4px) scale(1.08) !important;
        }

        .footer-social-btn.btn-gh:hover {
            background: linear-gradient(135deg, #24292e 0%, #0f172a 100%) !important;
            border-color: rgba(255, 255, 255, 0.4) !important;
            color: #ffffff !important;
            box-shadow: 0 8px 24px rgba(255, 255, 255, 0.35), inset 0 1px 0 rgba(255, 255, 255, 0.35) !important;
            transform: translateY(-4px) scale(1.08) !important;
        }
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>

    <!-- Header Navbar -->
    <nav class="pm-navbar">
        <div class="container-fluid px-3 px-sm-4 px-xl-5" style="max-width: 1560px;">
            <div class="d-flex align-items-center justify-content-between gap-2 gap-xl-3">
                <!-- Brand Logo (Single-Line, Zero Wrapping, Elegant Typography) -->
                <a href="<?php echo e(route('home')); ?>" class="pm-brand">
                    <?php if($siteLogo): ?>
                        <img src="<?php echo e(asset('storage/' . $siteLogo)); ?>" alt="<?php echo e($siteName); ?>" height="38" style="max-height: 40px; width: auto; object-fit: contain;">
                    <?php else: ?>
                        <div class="pm-brand-icon">
                            <i class="bi bi-file-earmark-pdf-fill"></i>
                        </div>
                    <?php endif; ?>
                    <span class="pm-brand-title">
                        <?php echo \App\Models\SystemSetting::formatBrandName($siteName); ?>

                    </span>
                </a>

                <!-- Desktop Navigation Links (Clean, Modern SaaS Navigation) -->
                <div class="d-none d-lg-flex align-items-center">
                    <ul class="pm-nav-list">
                        <li>
                            <a href="<?php echo e(route('home')); ?>" class="pm-nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">
                                Home
                            </a>
                        </li>
                        
                        <!-- All Tools with Dropdown Quick Menu -->
                        <li class="dropdown">
                            <a href="<?php echo e(route('tools.index')); ?>" 
                               class="pm-nav-link <?php echo e(request()->routeIs('tools.*') ? 'active' : ''); ?>" 
                               data-bs-toggle="dropdown" 
                               aria-expanded="false">
                                All Tools 
                                <i class="bi bi-chevron-down ms-1" style="font-size: 0.65rem; opacity: 0.7;"></i>
                            </a>
                            <div class="dropdown-menu pm-tools-dropdown-menu shadow border-0 mt-2 p-3">
                                <div class="row g-2">
                                    <div class="col-6">
                                        <div class="text-uppercase text-muted fw-bold small px-2 mb-2" style="font-size: 0.68rem; letter-spacing: 0.05em;">Popular Tools</div>
                                        <a href="<?php echo e(route('tool.show', 'merge-pdf')); ?>" class="pm-dropdown-item-tool">
                                            <div class="pm-dropdown-tool-icon" style="background: #2563eb;"><i class="bi bi-files"></i></div>
                                            <div>
                                                <div class="fw-bold small">Merge PDF</div>
                                                <div class="text-muted" style="font-size: 0.72rem;">Combine files</div>
                                            </div>
                                        </a>
                                        <a href="<?php echo e(route('tool.show', 'compress-pdf')); ?>" class="pm-dropdown-item-tool">
                                            <div class="pm-dropdown-tool-icon" style="background: #f59e0b;"><i class="bi bi-file-earmark-zip"></i></div>
                                            <div>
                                                <div class="fw-bold small">Compress PDF</div>
                                                <div class="text-muted" style="font-size: 0.72rem;">Reduce size</div>
                                            </div>
                                        </a>
                                        <a href="<?php echo e(route('tool.show', 'edit-pdf')); ?>" class="pm-dropdown-item-tool">
                                            <div class="pm-dropdown-tool-icon" style="background: #0284c7;"><i class="bi bi-pencil-square"></i></div>
                                            <div>
                                                <div class="fw-bold small">Edit PDF</div>
                                                <div class="text-muted" style="font-size: 0.72rem;">Add text & annotate</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-6">
                                        <div class="text-uppercase text-muted fw-bold small px-2 mb-2" style="font-size: 0.68rem; letter-spacing: 0.05em;">Convert & Sign</div>
                                        <a href="<?php echo e(route('tool.show', 'pdf-to-word')); ?>" class="pm-dropdown-item-tool">
                                            <div class="pm-dropdown-tool-icon" style="background: #4f46e5;"><i class="bi bi-filetype-docx"></i></div>
                                            <div>
                                                <div class="fw-bold small">PDF to Word</div>
                                                <div class="text-muted" style="font-size: 0.72rem;">Editable DOCX</div>
                                            </div>
                                        </a>
                                        <a href="<?php echo e(route('tool.show', 'sign-pdf')); ?>" class="pm-dropdown-item-tool">
                                            <div class="pm-dropdown-tool-icon" style="background: #10b981;"><i class="bi bi-pen"></i></div>
                                            <div>
                                                <div class="fw-bold small">Sign PDF</div>
                                                <div class="text-muted" style="font-size: 0.72rem;">Digital signature</div>
                                            </div>
                                        </a>
                                        <a href="<?php echo e(route('tool.show', 'word-to-pdf')); ?>" class="pm-dropdown-item-tool">
                                            <div class="pm-dropdown-tool-icon" style="background: #ec4899;"><i class="bi bi-file-earmark-arrow-up"></i></div>
                                            <div>
                                                <div class="fw-bold small">Word to PDF</div>
                                                <div class="text-muted" style="font-size: 0.72rem;">Convert to PDF</div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="border-top mt-2 pt-2 text-center">
                                    <a href="<?php echo e(route('tools.index')); ?>" class="btn btn-sm btn-light border w-100 rounded-pill py-1.5 fw-bold text-primary small">
                                        <i class="bi bi-grid-3x3-gap-fill me-1"></i> View All 68+ PDF Tools &rarr;
                                    </a>
                                </div>
                            </div>
                        </li>

                        <li>
                            <a href="<?php echo e(route('templates.index')); ?>" class="pm-nav-link <?php echo e(request()->routeIs('templates.*') ? 'active' : ''); ?>">
                                <i class="bi bi-file-earmark-spreadsheet me-1 text-primary"></i> Templates
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('customer.ai-assistant')); ?>" class="pm-nav-link <?php echo e(request()->routeIs('customer.ai-assistant*') ? 'active' : ''); ?>">
                                <i class="bi bi-robot me-1 text-info"></i> AI Assistant
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('forms.index')); ?>" class="pm-nav-link <?php echo e(request()->routeIs('forms.*') ? 'active' : ''); ?>">
                                PDF Forms
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('pricing')); ?>" class="pm-nav-link <?php echo e(request()->routeIs('pricing') ? 'active' : ''); ?>">
                                Pricing
                            </a>
                        </li>

                        <!-- More Dropdown for Secondary Navigation -->
                        <li class="dropdown">
                            <a href="#" class="pm-nav-link <?php echo e(request()->routeIs('blog.*', 'about', 'contact', 'faq') ? 'active' : ''); ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                More <i class="bi bi-chevron-down ms-1" style="font-size: 0.65rem; opacity: 0.7;"></i>
                            </a>
                            <ul class="dropdown-menu shadow border-0 rounded-4 mt-2 p-2">
                                <li>
                                    <a class="dropdown-item py-2 rounded-3 small <?php echo e(request()->routeIs('blog.*') ? 'active fw-bold' : ''); ?>" href="<?php echo e(route('blog.index')); ?>">
                                        <i class="bi bi-journal-richtext text-primary me-2"></i> Blog & News
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item py-2 rounded-3 small <?php echo e(request()->routeIs('about') ? 'active fw-bold' : ''); ?>" href="<?php echo e(route('about')); ?>">
                                        <i class="bi bi-info-circle text-info me-2"></i> About <?php echo e($siteName); ?>

                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item py-2 rounded-3 small <?php echo e(request()->routeIs('contact') ? 'active fw-bold' : ''); ?>" href="<?php echo e(route('contact')); ?>">
                                        <i class="bi bi-envelope text-success me-2"></i> Contact & Help
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item py-2 rounded-3 small <?php echo e(request()->routeIs('faq') ? 'active fw-bold' : ''); ?>" href="<?php echo e(route('faq')); ?>">
                                        <i class="bi bi-question-circle text-warning me-2"></i> FAQ Center
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>

                <!-- Right Actions Toolbar -->
                <div class="pm-header-actions">
                    <!-- Modern Search Input (Perfect Centering, Never Misaligned) -->
                    <form action="<?php echo e(route('tools.index')); ?>" method="GET" class="d-none d-xl-flex pm-header-search-form">
                        <div class="pm-search-box">
                            <i class="bi bi-search pm-search-icon"></i>
                            <input type="text" name="search" class="pm-search-input" placeholder="Search 68+ PDF tools..." autocomplete="off">
                        </div>
                    </form>

                    <!-- Auth State Buttons -->
                    <?php if(auth()->guard()->check()): ?>
                        <div class="dropdown">
                            <button class="pm-user-btn dropdown-toggle shadow-sm" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <div class="pm-user-avatar">
                                    <?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?>

                                </div>
                                <span class="d-none d-md-inline text-truncate" style="max-width: 80px;"><?php echo e(auth()->user()->name); ?></span>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end shadow border-0 rounded-4 mt-2 p-2" style="min-width: 220px;">
                                <li class="px-3 py-1.5 text-muted small border-bottom mb-1">
                                    Signed in as <strong class="d-block text-dark text-truncate"><?php echo e(auth()->user()->email); ?></strong>
                                </li>
                                <?php if(auth()->user()->isAdmin()): ?>
                                    <li>
                                        <a class="dropdown-item py-2 rounded-3 text-warning fw-bold" href="<?php echo e(route('admin.dashboard')); ?>">
                                            <i class="bi bi-shield-lock-fill text-warning me-2"></i> Admin Panel
                                        </a>
                                    </li>
                                <?php endif; ?>
                                <li>
                                    <a class="dropdown-item py-2 rounded-3" href="<?php echo e(route('customer.dashboard')); ?>">
                                        <i class="bi bi-grid-fill text-primary me-2"></i> User Dashboard
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item py-2 rounded-3" href="<?php echo e(route('customer.files')); ?>">
                                        <i class="bi bi-file-earmark-check text-secondary me-2"></i> My Documents
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item py-2 rounded-3" href="<?php echo e(route('customer.subscription')); ?>">
                                        <i class="bi bi-credit-card text-success me-2"></i> Subscription Plan
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item py-2 rounded-3" href="<?php echo e(route('customer.profile')); ?>">
                                        <i class="bi bi-gear text-secondary me-2"></i> Profile Settings
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider my-1"></li>
                                <li>
                                    <form action="<?php echo e(route('logout')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="dropdown-item py-2 rounded-3 text-danger">
                                            <i class="bi bi-box-arrow-right me-2"></i> Logout
                                        </button>
                                    </form>
                                </li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="btn-pm-login shadow-sm">
                            <i class="bi bi-box-arrow-in-right"></i>
                            <span>Login</span>
                        </a>
                        <a href="<?php echo e(route('register')); ?>" class="btn-pm-cta shadow-sm d-none d-sm-inline-flex">
                            <i class="bi bi-person-plus-fill"></i>
                            <span>Sign Up to Free Trial</span>
                        </a>
                    <?php endif; ?>

                    <!-- Mobile Toggler -->
                    <button class="pm-mobile-btn d-lg-none" type="button" data-bs-toggle="collapse" data-bs-target="#mobileMenu" aria-label="Toggle Navigation">
                        <i class="bi bi-list fs-5"></i>
                    </button>
                </div>
            </div>

            <!-- Mobile Drawer Menu -->
            <div class="collapse d-lg-none mt-3" id="mobileMenu">
                <div class="p-3 bg-white border rounded-4 shadow-sm">
                    <form action="<?php echo e(route('tools.index')); ?>" method="GET" class="mb-3">
                        <div class="input-group">
                            <span class="input-group-text bg-light border-end-0"><i class="bi bi-search text-muted"></i></span>
                            <input type="text" name="search" class="form-control border-start-0 shadow-none" placeholder="Search 68+ PDF tools...">
                        </div>
                    </form>
                    <ul class="nav flex-column gap-1 mb-3">
                        <li><a class="nav-link-custom w-100 <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>"><i class="bi bi-house-door me-2"></i> Home</a></li>
                        <li><a class="nav-link-custom w-100 <?php echo e(request()->routeIs('tools.*') ? 'active' : ''); ?>" href="<?php echo e(route('tools.index')); ?>"><i class="bi bi-grid-fill me-2"></i> All Tools</a></li>
                        <li><a class="nav-link-custom w-100 <?php echo e(request()->routeIs('templates.*') ? 'active' : ''); ?>" href="<?php echo e(route('templates.index')); ?>"><i class="bi bi-file-earmark-spreadsheet me-2 text-warning"></i> PDF Templates</a></li>
                        <li><a class="nav-link-custom w-100 <?php echo e(request()->routeIs('customer.ai-assistant*') ? 'active' : ''); ?>" href="<?php echo e(route('customer.ai-assistant')); ?>"><i class="bi bi-robot me-2 text-info"></i> AI Assistant</a></li>
                        <li><a class="nav-link-custom w-100 <?php echo e(request()->routeIs('forms.*') ? 'active' : ''); ?>" href="<?php echo e(route('forms.index')); ?>"><i class="bi bi-file-earmark-text me-2"></i> PDF Forms</a></li>
                        <li><a class="nav-link-custom w-100 <?php echo e(request()->routeIs('pricing') ? 'active' : ''); ?>" href="<?php echo e(route('pricing')); ?>"><i class="bi bi-tag-fill me-2"></i> Pricing</a></li>
                        <li><a class="nav-link-custom w-100 <?php echo e(request()->routeIs('blog.*') ? 'active' : ''); ?>" href="<?php echo e(route('blog.index')); ?>"><i class="bi bi-journal-richtext me-2"></i> Blog</a></li>
                        <li><a class="nav-link-custom w-100 <?php echo e(request()->routeIs('about') ? 'active' : ''); ?>" href="<?php echo e(route('about')); ?>"><i class="bi bi-info-circle-fill me-2"></i> About</a></li>
                        <li><a class="nav-link-custom w-100 <?php echo e(request()->routeIs('contact') ? 'active' : ''); ?>" href="<?php echo e(route('contact')); ?>"><i class="bi bi-envelope-fill me-2"></i> Contact</a></li>
                    </ul>
                    <?php if(auth()->guard()->check()): ?>
                        <div class="pt-3 border-top">
                            <div class="d-flex align-items-center gap-2 mb-3 px-1">
                                <div class="pm-user-avatar"><?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?></div>
                                <div class="overflow-hidden">
                                    <strong class="d-block text-dark text-truncate small"><?php echo e(auth()->user()->name); ?></strong>
                                    <span class="text-muted small" style="font-size: 0.72rem;"><?php echo e(auth()->user()->email); ?></span>
                                </div>
                            </div>
                            <div class="d-grid gap-2">
                                <a href="<?php echo e(route('customer.dashboard')); ?>" class="btn btn-sm btn-primary rounded-pill py-2 fw-bold text-center">
                                    <i class="bi bi-grid-fill me-1"></i> User Dashboard
                                </a>
                                <?php if(auth()->user()->isAdmin()): ?>
                                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-sm btn-warning text-dark rounded-pill py-2 fw-bold text-center">
                                        <i class="bi bi-shield-lock-fill me-1"></i> Admin Panel
                                    </a>
                                <?php endif; ?>
                                <form action="<?php echo e(route('logout')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger rounded-pill py-2 fw-bold w-100 text-center">
                                        <i class="bi bi-box-arrow-right me-1"></i> Logout
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="d-grid gap-2 pt-2 border-top">
                            <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-primary rounded-pill py-2 fw-bold text-center">
                                <i class="bi bi-box-arrow-in-right me-1"></i> Login
                            </a>
                            <a href="<?php echo e(route('register')); ?>" class="btn btn-pm-blue rounded-pill py-2 fw-bold text-center">
                                <i class="bi bi-person-plus-fill me-1"></i> Sign Up to Free Trial
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="flex-grow-1">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <!-- Footer with Crystal-Clear Contrast & Dynamic Social Media Controls -->
    <footer class="pm-footer-dark">
        <div class="container">
            <div class="row g-4 mb-5">
                <!-- Col 1: Brand & Dynamic Social Profiles -->
                <div class="col-lg-4">
                    <a href="<?php echo e(route('home')); ?>" class="d-flex align-items-center gap-2 mb-3 text-decoration-none">
                        <?php if($siteLogo): ?>
                            <img src="<?php echo e(asset('storage/' . $siteLogo)); ?>" alt="<?php echo e($siteName); ?>" height="36" style="max-height: 38px; width: auto; object-fit: contain;">
                        <?php else: ?>
                            <div class="pm-brand-icon">
                                <i class="bi bi-file-earmark-pdf-fill"></i>
                            </div>
                        <?php endif; ?>
                        <span class="fw-bold fs-4 text-white"><?php echo e($siteName); ?></span>
                    </a>
                    <p class="pm-footer-desc mb-4" style="max-width: 340px;">
                        <?php echo e(\App\Models\SystemSetting::get('site_tagline', 'All-in-one PDF SaaS Platform. Make your PDF work fast, effortless and 100% secure.')); ?>

                    </p>

                    <?php
                        $fb = \App\Models\SystemSetting::get('social_facebook', 'https://facebook.com');
                        $tw = \App\Models\SystemSetting::get('social_twitter', 'https://twitter.com');
                        $ig = \App\Models\SystemSetting::get('social_instagram', 'https://instagram.com');
                        $li = \App\Models\SystemSetting::get('social_linkedin', 'https://linkedin.com');
                        $yt = \App\Models\SystemSetting::get('social_youtube', 'https://youtube.com');
                        $wa = \App\Models\SystemSetting::get('social_whatsapp');
                        $tg = \App\Models\SystemSetting::get('social_telegram');
                        $gh = \App\Models\SystemSetting::get('social_github');
                    ?>
                    <div class="pm-social-list">
                        <?php if($fb): ?><a href="<?php echo e($fb); ?>" target="_blank" rel="noopener noreferrer" class="footer-social-btn btn-fb" title="Follow us on Facebook"><i class="bi bi-facebook"></i></a><?php endif; ?>
                        <?php if($tw): ?><a href="<?php echo e($tw); ?>" target="_blank" rel="noopener noreferrer" class="footer-social-btn btn-tw" title="Follow us on Twitter / X"><i class="bi bi-twitter-x"></i></a><?php endif; ?>
                        <?php if($ig): ?><a href="<?php echo e($ig); ?>" target="_blank" rel="noopener noreferrer" class="footer-social-btn btn-ig" title="Follow us on Instagram"><i class="bi bi-instagram"></i></a><?php endif; ?>
                        <?php if($li): ?><a href="<?php echo e($li); ?>" target="_blank" rel="noopener noreferrer" class="footer-social-btn btn-li" title="Follow us on LinkedIn"><i class="bi bi-linkedin"></i></a><?php endif; ?>
                        <?php if($yt): ?><a href="<?php echo e($yt); ?>" target="_blank" rel="noopener noreferrer" class="footer-social-btn btn-yt" title="Subscribe on YouTube"><i class="bi bi-youtube"></i></a><?php endif; ?>
                        <?php if($wa): ?><a href="<?php echo e($wa); ?>" target="_blank" rel="noopener noreferrer" class="footer-social-btn btn-wa" title="Chat on WhatsApp"><i class="bi bi-whatsapp"></i></a><?php endif; ?>
                        <?php if($tg): ?><a href="<?php echo e($tg); ?>" target="_blank" rel="noopener noreferrer" class="footer-social-btn btn-tg" title="Join on Telegram"><i class="bi bi-telegram"></i></a><?php endif; ?>
                        <?php if($gh): ?><a href="<?php echo e($gh); ?>" target="_blank" rel="noopener noreferrer" class="footer-social-btn btn-gh" title="Fork on GitHub"><i class="bi bi-github"></i></a><?php endif; ?>
                    </div>
                </div>

                <!-- Col 2: Quick Links -->
                <div class="col-6 col-md-3 col-lg-2">
                    <h6>Quick Links</h6>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li><a href="<?php echo e(route('tools.index')); ?>">All PDF Tools</a></li>
                        <li><a href="<?php echo e(route('forms.index')); ?>">Official Forms</a></li>
                        <li><a href="<?php echo e(route('pricing')); ?>">Pricing & Plans</a></li>
                        <li><a href="<?php echo e(route('blog.index')); ?>">Blog & Daily News</a></li>
                        <li><a href="<?php echo e(route('about')); ?>">About Us</a></li>
                        <li><a href="<?php echo e(route('contact')); ?>">Contact Support</a></li>
                    </ul>
                </div>

                <!-- Col 3: Popular PDF Tools -->
                <div class="col-6 col-md-3 col-lg-2">
                    <h6>Popular Tools</h6>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo e(route('tool.show', 'merge-pdf')); ?>">Merge PDF</a></li>
                        <li><a href="<?php echo e(route('tool.show', 'compress-pdf')); ?>">Compress PDF</a></li>
                        <li><a href="<?php echo e(route('tool.show', 'edit-pdf')); ?>">Edit PDF</a></li>
                        <li><a href="<?php echo e(route('tool.show', 'pdf-to-word')); ?>">PDF to Word</a></li>
                        <li><a href="<?php echo e(route('tool.show', 'sign-pdf')); ?>">Sign PDF Online</a></li>
                        <li><a href="<?php echo e(route('forms.index')); ?>">Tax & Legal Forms</a></li>
                    </ul>
                </div>

                <!-- Col 4: Support & Security -->
                <div class="col-6 col-md-3 col-lg-2">
                    <h6>Support & Trust</h6>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo e(route('faq')); ?>">Help & FAQ</a></li>
                        <li><a href="<?php echo e(route('contact')); ?>">Customer Care</a></li>
                        <li><a href="<?php echo e(route('privacy')); ?>">Privacy Policy</a></li>
                        <li><a href="<?php echo e(route('terms')); ?>">Terms of Service</a></li>
                    </ul>
                </div>

                <!-- Col 5: Newsletter Subscribe Box -->
                <div class="col-6 col-md-3 col-lg-2">
                    <h6>Stay Updated</h6>
                    <p class="pm-footer-desc mb-2" style="font-size: 0.82rem;">Subscribe for weekly productivity updates and free PDF tools.</p>
                    <form onsubmit="event.preventDefault(); alert('Thank you for subscribing to <?php echo e($siteName); ?> newsletter!');">
                        <div class="input-group mb-2">
                            <input type="email" class="form-control form-control-sm text-white" style="background: rgba(255,255,255,0.08); border-color: rgba(255,255,255,0.2);" placeholder="Your email address" required>
                        </div>
                        <button type="submit" class="btn btn-sm btn-pm-blue w-100 rounded-pill shadow-sm">
                            <i class="bi bi-send me-1"></i> Subscribe
                        </button>
                    </form>
                </div>
            </div>

            <!-- Bottom Copyright Bar -->
            <div class="pt-4 border-top border-white border-opacity-10 d-flex flex-column flex-md-row justify-content-between align-items-center gap-3" style="font-size: 0.85rem; color: #cbd5e1;">
                <div>
                    &copy; <?php echo e(date('Y')); ?> <strong class="text-white"><?php echo e($siteName); ?></strong>. All rights reserved. Built with enterprise-grade PDF processing.
                </div>
                <div class="d-flex align-items-center gap-2">
                    <i class="bi bi-shield-check text-success"></i>
                    <span>256-bit SSL Encrypted</span>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.documentElement.setAttribute('data-bs-theme', 'light');
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\Websites\Dynamic Website\Laravel First Website\PDFMasster\.PDFMaster\resources\views/layouts/app.blade.php ENDPATH**/ ?>