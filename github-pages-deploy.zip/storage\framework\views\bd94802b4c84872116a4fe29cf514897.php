<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php
        $custSiteName = $siteName ?? \App\Models\SystemSetting::get('site_name', 'PDF Master');
        $custFavicon = $siteFavicon ?? \App\Models\SystemSetting::get('site_favicon');
        $custLogo = $siteLogo ?? \App\Models\SystemSetting::get('site_logo');
    ?>
    <?php if($custFavicon): ?>
        <link rel="icon" type="image/x-icon" href="<?php echo e(asset('storage/' . $custFavicon)); ?>">
        <link rel="shortcut icon" href="<?php echo e(asset('storage/' . $custFavicon)); ?>">
    <?php else: ?>
        <link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>">
    <?php endif; ?>
    <title><?php echo $__env->yieldContent('title', 'Customer Dashboard'); ?> — <?php echo e($custSiteName); ?></title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

    <!-- Laravel Vite Application Styles & Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: #f8fafc;
            color: #1e293b;
            min-height: 100vh;
        }

        /* Dark Navy Sidebar Matching Panel 9 */
        .cust-sidebar {
            width: 250px;
            background: #0b1329;
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 1040;
            overflow-y: auto;
            color: #94a3b8;
        }

        .cust-brand {
            padding: 1.5rem 1.25rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            color: #ffffff;
            text-decoration: none;
            font-weight: 800;
            font-size: 1.2rem;
            border-bottom: 1px solid #1e293b;
        }

        .cust-user-profile {
            padding: 1.25rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            border-bottom: 1px solid #1e293b;
        }

        .cust-avatar {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            background: #2563eb;
            color: #ffffff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1.1rem;
        }

        .cust-nav-link {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.65rem 1.25rem;
            color: #94a3b8;
            font-size: 0.88rem;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.2s ease;
        }

        .cust-nav-link:hover {
            color: #ffffff;
            background: rgba(255, 255, 255, 0.05);
        }

        .cust-nav-link.active {
            color: #ffffff;
            background: #2563eb;
            font-weight: 600;
        }

        .cust-main-content {
            margin-left: 250px;
            padding: 2rem;
            min-height: 100vh;
        }

        .cust-backdrop {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(11, 19, 41, 0.65);
            backdrop-filter: blur(2px);
            z-index: 1045;
        }

        .cust-backdrop.show {
            display: block;
        }

        .cust-topbar-mobile {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 14px;
            padding: 0.65rem 1rem;
            margin-bottom: 1.25rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.03);
        }

        @media (max-width: 991.98px) {
            .cust-sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
                z-index: 1050;
            }
            .cust-sidebar.show {
                transform: translateX(0);
                box-shadow: 0 10px 30px rgba(0,0,0,0.5);
            }
            .cust-main-content {
                margin-left: 0 !important;
                padding: 1rem 0.85rem !important;
            }
        }
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>

    <!-- Backdrop Overlay for Mobile -->
    <div class="cust-backdrop" id="custBackdrop"></div>

    <!-- Dark Navy Sidebar Matching Panel 9 -->
    <aside class="cust-sidebar" id="custSidebar">
        <!-- Brand with Mobile Close Button -->
        <div class="cust-brand justify-content-between">
            <a href="<?php echo e(route('home')); ?>" class="d-flex align-items-center gap-2 text-white text-decoration-none">
                <?php if($custLogo): ?>
                    <img src="<?php echo e(asset('storage/' . $custLogo)); ?>" alt="<?php echo e($custSiteName); ?>" height="32" class="rounded" style="max-height: 34px; width: auto; object-fit: contain;">
                <?php else: ?>
                    <div style="background: #2563eb; width: 34px; height: 34px; border-radius: 8px; display: flex; align-items: center; justify-content: center;">
                        <i class="bi bi-file-earmark-pdf-fill"></i>
                    </div>
                <?php endif; ?>
                <span><?php echo \App\Models\SystemSetting::formatBrandName($custSiteName); ?></span>
            </a>
            <button type="button" class="btn-close btn-close-white d-lg-none" id="custSidebarCloseBtn" aria-label="Close"></button>
        </div>

        <!-- User Profile Card -->
        <div class="cust-user-profile">
            <div class="cust-avatar">
                <?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?>

            </div>
            <div class="overflow-hidden">
                <div class="fw-bold text-white text-truncate small"><?php echo e(auth()->user()->name); ?></div>
                <div class="text-muted text-truncate" style="font-size: 0.75rem;"><?php echo e(auth()->user()->email); ?></div>
            </div>
        </div>

        <!-- Navigation Links Matching Reference Panel 9 -->
        <div class="py-3">
            <a href="<?php echo e(route('customer.dashboard')); ?>" class="cust-nav-link <?php echo e(request()->routeIs('customer.dashboard') ? 'active' : ''); ?>">
                <i class="bi bi-grid-1x2"></i> Dashboard
            </a>
            <a href="<?php echo e(route('customer.ai-assistant')); ?>" class="cust-nav-link <?php echo e(request()->routeIs('customer.ai-assistant*') ? 'active' : ''); ?>">
                <i class="bi bi-robot text-info"></i> AI PDF Assistant
            </a>
            <a href="<?php echo e(route('customer.cloud-storage.index')); ?>" class="cust-nav-link <?php echo e(request()->routeIs('customer.cloud-storage*') ? 'active' : ''); ?>">
                <i class="bi bi-cloud-arrow-up text-primary"></i> Cloud Storage Hub
            </a>
            <a href="<?php echo e(route('templates.index')); ?>" class="cust-nav-link <?php echo e(request()->routeIs('templates.*') ? 'active' : ''); ?>">
                <i class="bi bi-file-earmark-spreadsheet text-warning"></i> Template Studio
            </a>
            <a href="<?php echo e(route('tools.index')); ?>" class="cust-nav-link">
                <i class="bi bi-tools"></i> PDF Tools & Batch
            </a>
            <a href="<?php echo e(route('customer.files')); ?>" class="cust-nav-link <?php echo e(request()->routeIs('customer.files') ? 'active' : ''); ?>">
                <i class="bi bi-file-earmark-check"></i> Processed Files
            </a>
            <a href="<?php echo e(route('forms.index')); ?>" class="cust-nav-link <?php echo e(request()->routeIs('forms.*') ? 'active' : ''); ?>">
                <i class="bi bi-ui-checks"></i> PDF Forms Center
            </a>
            <a href="<?php echo e(route('customer.subscription')); ?>" class="cust-nav-link <?php echo e(request()->routeIs('customer.subscription') ? 'active' : ''); ?>">
                <i class="bi bi-credit-card"></i> Subscription & Billing
            </a>
            <a href="<?php echo e(route('customer.profile')); ?>" class="cust-nav-link <?php echo e(request()->routeIs('customer.profile') ? 'active' : ''); ?>">
                <i class="bi bi-gear"></i> Profile Settings
            </a>
            <?php if(auth()->user()->isAdmin()): ?>
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="cust-nav-link text-warning fw-bold">
                    <i class="bi bi-shield-lock-fill"></i> Admin Panel
                </a>
            <?php endif; ?>
            <a href="<?php echo e(route('contact')); ?>" class="cust-nav-link">
                <i class="bi bi-headset"></i> 24/7 Support
            </a>

            <div class="mt-4 px-3">
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-sm btn-outline-danger w-100 rounded-pill py-2">
                        <i class="bi bi-box-arrow-left me-1"></i> Logout
                    </button>
                </form>
            </div>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="cust-main-content">
        <!-- Mobile Topbar Toggle -->
        <div class="d-lg-none cust-topbar-mobile d-flex justify-content-between align-items-center">
            <button class="btn btn-sm btn-dark rounded-3 px-2.5 py-1.5 shadow-sm" id="custMobileToggleBtn" type="button" aria-label="Open Menu">
                <i class="bi bi-list fs-5"></i>
            </button>
            <div class="fw-bold fs-6">
                <?php echo \App\Models\SystemSetting::formatBrandName($custSiteName); ?>

            </div>
            <div class="cust-avatar" style="width: 32px; height: 32px; font-size: 0.85rem;">
                <?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?>

            </div>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show rounded-3 border-0 shadow-sm mb-4">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const custSidebar = document.getElementById('custSidebar');
            const custBackdrop = document.getElementById('custBackdrop');
            const custMobileToggleBtn = document.getElementById('custMobileToggleBtn');
            const custSidebarCloseBtn = document.getElementById('custSidebarCloseBtn');

            function openSidebar() {
                if (custSidebar) custSidebar.classList.add('show');
                if (custBackdrop) custBackdrop.classList.add('show');
                document.body.style.overflow = 'hidden';
            }

            function closeSidebar() {
                if (custSidebar) custSidebar.classList.remove('show');
                if (custBackdrop) custBackdrop.classList.remove('show');
                document.body.style.overflow = '';
            }

            if (custMobileToggleBtn) custMobileToggleBtn.addEventListener('click', openSidebar);
            if (custSidebarCloseBtn) custSidebarCloseBtn.addEventListener('click', closeSidebar);
            if (custBackdrop) custBackdrop.addEventListener('click', closeSidebar);

            // Auto close when nav link is clicked on mobile
            const navLinks = custSidebar ? custSidebar.querySelectorAll('.cust-nav-link') : [];
            navLinks.forEach(link => {
                link.addEventListener('click', function () {
                    if (window.innerWidth < 992) {
                        closeSidebar();
                    }
                });
            });
        });
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\Websites\Dynamic Website\Laravel First Website\PDFMasster\.PDFMaster\resources\views/layouts/customer.blade.php ENDPATH**/ ?>