<?php $__env->startSection('title', 'Dashboard — Customer Portal'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid p-0">

    <div class="mb-4">
        <h4 class="fw-bold text-dark mb-1">Dashboard</h4>
        <p class="text-muted small mb-0">Overview of your PDF documents and subscription status.</p>
    </div>

    <?php
        $isExpired = $user->isPlanExpired();
        $isPro = $user->isPro();
        $startDate = $startDate ?? $user->subscriptionStartDate();
        $endDate = $endDate ?? $user->subscriptionEndDate();
        $daysLeft = $user->daysRemaining();
    ?>

    <?php if($isExpired): ?>
        <div class="alert alert-danger border-0 rounded-4 p-3.5 mb-4 shadow-sm d-flex flex-wrap align-items-center justify-content-between gap-3" style="background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%); border-left: 5px solid #dc2626 !important;">
            <div class="d-flex align-items-center gap-3">
                <div class="p-2.5 rounded-circle bg-danger text-white">
                    <i class="bi bi-exclamation-octagon-fill fs-4"></i>
                </div>
                <div>
                    <h6 class="fw-bold text-danger mb-0">⚠️ <?php echo e($plan->name ?? 'Pro'); ?> Plan Expired • Quota Finished</h6>
                    <p class="text-secondary small mb-0">
                        Your subscription ended on <strong><?php echo e($endDate?->format('M d, Y')); ?></strong> (Started: <?php echo e($startDate?->format('M d, Y')); ?>). Your Pro operations quota is finished. Please renew your subscription to resume tools access!
                    </p>
                </div>
            </div>
            <a href="<?php echo e(route('pricing')); ?>" class="btn btn-sm btn-danger fw-bold px-3.5 py-2 rounded-pill shadow-sm">
                <i class="bi bi-arrow-repeat me-1"></i> Renew Subscription
            </a>
        </div>
    <?php else: ?>
        <div class="alert alert-success border-0 rounded-4 p-3.5 mb-4 shadow-sm d-flex flex-wrap align-items-center justify-content-between gap-3" style="background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%); border-left: 5px solid #16a34a !important;">
            <div class="d-flex align-items-center gap-3">
                <div class="p-2.5 rounded-circle <?php echo e($isPro ? 'bg-primary text-white' : 'bg-warning text-dark'); ?>">
                    <i class="bi <?php echo e($isPro ? 'bi-patch-check-fill' : 'bi-stars'); ?> fs-4"></i>
                </div>
                <div>
                    <?php if($isPro): ?>
                        <h6 class="fw-bold text-dark mb-0">🎉 <?php echo e($plan->name ?? 'Pro'); ?> Membership Active</h6>
                        <p class="text-secondary small mb-0">
                            Approved & Valid from <strong><?php echo e($startDate?->format('M d, Y')); ?></strong> until <strong><?php echo e($endDate?->format('M d, Y')); ?></strong> (<?php echo e($daysLeft); ?> days remaining). High-speed priority queue active.
                        </p>
                    <?php elseif($user->onTrial()): ?>
                        <h6 class="fw-bold text-dark mb-0">✨ Free Trial Active (<?php echo e($user->trialDaysRemaining()); ?> Days Remaining)</h6>
                        <p class="text-secondary small mb-0">Enjoy full Pro capabilities until <?php echo e($user->trial_ends_at?->format('M d, Y')); ?>.</p>
                    <?php else: ?>
                        <h6 class="fw-bold text-dark mb-0">⚡ Free Plan Active (<?php echo e($user->daily_operations_count); ?> / <?php echo e($plan->max_daily_operations ?? 5); ?> Operations Today)</h6>
                        <p class="text-secondary small mb-0">Upgrade to Pro for 100 daily operations, 100MB file limits, batch tools, and priority conversion speed.</p>
                    <?php endif; ?>
                </div>
            </div>
            <?php if(!$isPro): ?>
                <a href="<?php echo e(route('pricing')); ?>" class="btn btn-sm btn-primary fw-bold px-3.5 py-2 rounded-pill shadow-sm">
                    <i class="bi bi-arrow-up-circle-fill me-1"></i> Upgrade to Pro
                </a>
            <?php else: ?>
                <a href="<?php echo e(route('tools.index')); ?>" class="btn btn-sm btn-primary fw-bold px-3.5 py-2 rounded-pill shadow-sm">
                    <i class="bi bi-grid-fill me-1"></i> Launch PDF Tools
                </a>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <!-- 4 Metric Cards Matching Reference Panel 9 -->
    <div class="row g-3 mb-4">
        <!-- Total Files -->
        <div class="col-sm-6 col-xl-3">
            <div class="card card-saas p-3 border">
                <div class="d-flex align-items-center gap-3">
                    <div class="p-3 rounded-circle bg-primary bg-opacity-10 text-primary">
                        <i class="bi bi-files fs-4"></i>
                    </div>
                    <div>
                        <div class="text-muted small fw-semibold">Total Files</div>
                        <h4 class="fw-bold mb-0 text-dark"><?php echo e($totalFiles); ?></h4>
                    </div>
                </div>
            </div>
        </div>

        <!-- Downloads -->
        <div class="col-sm-6 col-xl-3">
            <div class="card card-saas p-3 border">
                <div class="d-flex align-items-center gap-3">
                    <div class="p-3 rounded-circle bg-danger bg-opacity-10 text-danger">
                        <i class="bi bi-download fs-4"></i>
                    </div>
                    <div>
                        <div class="text-muted small fw-semibold">Downloads</div>
                        <h4 class="fw-bold mb-0 text-dark"><?php echo e($totalFiles > 0 ? $totalFiles * 2 : 0); ?></h4>
                    </div>
                </div>
            </div>
        </div>

        <!-- Storage Used -->
        <div class="col-sm-6 col-xl-3">
            <div class="card card-saas p-3 border">
                <div class="d-flex align-items-center gap-3">
                    <div class="p-3 rounded-circle bg-warning bg-opacity-10 text-warning">
                        <i class="bi bi-hdd fs-4"></i>
                    </div>
                    <div>
                        <div class="text-muted small fw-semibold">Storage Used</div>
                        <h4 class="fw-bold mb-0 text-dark">
                            <?php echo e(round(\App\Models\ProcessedFile::where('user_id', $user->id)->sum('file_size') / 1048576, 1)); ?> MB
                        </h4>
                    </div>
                </div>
            </div>
        </div>

        <!-- Subscription -->
        <div class="col-sm-6 col-xl-3">
            <div class="card card-saas p-3 border <?php echo e($isExpired ? 'border-danger' : ''); ?>">
                <div class="d-flex align-items-center gap-3">
                    <div class="p-3 rounded-circle <?php echo e($isExpired ? 'bg-danger bg-opacity-10 text-danger' : ($isPro ? 'bg-primary bg-opacity-10 text-primary' : 'bg-secondary bg-opacity-10 text-secondary')); ?>">
                        <i class="bi <?php echo e($isExpired ? 'bi-calendar-x text-danger' : ($isPro ? 'bi-patch-check-fill text-primary' : 'bi-credit-card')); ?> fs-4"></i>
                    </div>
                    <div>
                        <div class="text-muted small fw-semibold">Current Plan</div>
                        <h5 class="fw-bold mb-0 text-dark">
                            <?php echo e($plan->name ?? 'Free'); ?>

                            <?php if($isExpired): ?>
                                <span class="badge bg-danger small ms-1" style="font-size: 0.65rem;">Expired</span>
                            <?php elseif(!$isPro): ?>
                                <a href="<?php echo e(route('pricing')); ?>" class="small text-primary text-decoration-none fw-semibold ms-1" style="font-size: 0.75rem;">Upgrade</a>
                            <?php endif; ?>
                        </h5>
                        <div class="small mt-1" style="font-size: 0.72rem;">
                            <?php if($isExpired): ?>
                                <span class="text-danger fw-semibold">Quota Finished</span>
                            <?php elseif($endDate): ?>
                                <span class="text-muted">Until <?php echo e($endDate->format('M d, Y')); ?></span>
                            <?php elseif($user->onTrial()): ?>
                                <span class="text-muted"><?php echo e($user->trialDaysRemaining()); ?>d trial left</span>
                            <?php else: ?>
                                <span class="text-muted">5 Ops / Day</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Files Table Matching Reference Panel 9 -->
    <div class="card card-saas p-4 border">
        <div class="d-flex align-items-center justify-content-between mb-3">
            <h6 class="fw-bold text-dark mb-0">Recent Files</h6>
            <a href="<?php echo e(route('tools.index')); ?>" class="btn btn-sm btn-pm-blue px-3">
                <i class="bi bi-plus-lg me-1"></i> New Operation
            </a>
        </div>

        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 small">
                <thead class="table-light">
                    <tr>
                        <th>File Name</th>
                        <th>Tool</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th class="text-end">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $recentFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <i class="bi bi-file-earmark-pdf-fill text-danger fs-5"></i>
                                <span class="fw-bold text-dark text-truncate" style="max-width: 250px;"><?php echo e($file->output_filename); ?></span>
                            </div>
                        </td>
                        <td>
                            <span class="text-secondary fw-semibold"><?php echo e($file->tool?->name ?? $file->tool_slug); ?></span>
                        </td>
                        <td class="text-muted"><?php echo e($file->created_at->format('M d, Y')); ?></td>
                        <td>
                            <span class="badge bg-success-subtle text-success px-3 py-1 rounded-pill">Completed</span>
                        </td>
                        <td class="text-end">
                            <a href="<?php echo e(route('tool.download', $file->download_token)); ?>" class="text-primary fw-bold text-decoration-none">
                                <i class="bi bi-download me-1"></i> Download
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted py-5">
                            No files processed yet. Start by using any PDF tool!
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Websites\Dynamic Website\Laravel First Website\PDFMasster\.PDFMaster\resources\views/customer/dashboard.blade.php ENDPATH**/ ?>