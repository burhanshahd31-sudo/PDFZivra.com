<?php $__env->startSection('title', 'Ready-Made PDF Templates Library — ' . \App\Models\SystemSetting::get('site_name', 'PDF Master')); ?>

<?php $__env->startSection('content'); ?>
<div class="py-5" style="background-color: #f8fafc; min-height: 800px;">
    <div class="container py-4">

        <!-- Header -->
        <div class="text-center mb-5" style="max-width: 800px; margin: 0 auto;">
            <div class="badge bg-primary bg-opacity-10 text-primary px-4 py-2 rounded-pill fw-bold mb-3 fs-6">
                <i class="bi bi-file-earmark-spreadsheet-fill me-1"></i> VIP Document Template Studio
            </div>
            <h1 class="display-5 fw-extrabold text-dark mb-3">Professional PDF Templates Library</h1>
            <p class="lead text-secondary" style="font-size: 1.15rem; line-height: 1.6;">
                Generate corporate-grade invoices, executive resumes, client proposals, NDAs, and completion certificates in seconds. Fully customizable with direct PDF export.
            </p>
        </div>

        <!-- Search & Filter Nav -->
        <div class="card card-saas p-3 mb-5 border shadow-sm rounded-4">
            <div class="row g-3 align-items-center">
                <div class="col-lg-8">
                    <div class="d-flex gap-2 overflow-x-auto py-1 px-1 custom-scrollbar text-nowrap">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catKey => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('templates.index', ['category' => $catKey, 'search' => $search])); ?>" 
                               class="btn btn-sm rounded-pill px-3 py-2 fw-semibold flex-shrink-0 <?php echo e($category === $catKey ? 'btn-primary shadow-sm' : 'btn-light text-secondary border'); ?>">
                                <i class="bi <?php echo e($cat['icon']); ?> me-1"></i> <?php echo e($cat['name']); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="col-lg-4">
                    <form action="<?php echo e(route('templates.index')); ?>" method="GET">
                        <input type="hidden" name="category" value="<?php echo e($category); ?>">
                        <div class="input-group shadow-sm rounded-pill overflow-hidden border">
                            <input type="text" name="search" value="<?php echo e($search); ?>" class="form-control border-0 px-3" placeholder="Search templates...">
                            <button type="submit" class="btn btn-primary px-3">
                                <i class="bi bi-search"></i>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Templates Grid -->
        <?php if($templates->isEmpty()): ?>
            <div class="text-center py-5">
                <div class="p-4 rounded-circle bg-light d-inline-block mb-3">
                    <i class="bi bi-file-earmark-x fs-1 text-muted"></i>
                </div>
                <h4 class="fw-bold text-dark">No templates found</h4>
                <p class="text-muted">Try selecting another category or clearing your search filter.</p>
                <a href="<?php echo e(route('templates.index')); ?>" class="btn btn-outline-primary rounded-pill px-4">View All Templates</a>
            </div>
        <?php else: ?>
            <div class="row g-4">
                <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tmpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="card h-100 card-saas p-4 border shadow-sm rounded-4 position-relative d-flex flex-column" style="transition: transform 0.2s ease, box-shadow 0.2s ease;">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <div class="p-3 rounded-4 bg-primary bg-opacity-10 text-primary">
                                    <i class="bi <?php echo e($tmpl->icon); ?> fs-3"></i>
                                </div>
                                <div class="d-flex align-items-center gap-1">
                                    <?php if($tmpl->badge): ?>
                                        <span class="badge bg-warning bg-opacity-10 text-dark border border-warning border-opacity-25 rounded-pill px-2.5 py-1 small fw-bold">
                                            <?php echo e($tmpl->badge); ?>

                                        </span>
                                    <?php endif; ?>
                                    <?php if($tmpl->is_premium): ?>
                                        <span class="badge bg-primary rounded-pill px-2.5 py-1 small fw-bold">
                                            <i class="bi bi-star-fill text-warning me-1"></i> VIP Pro
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 rounded-pill px-2.5 py-1 small fw-bold">
                                            Free
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <h5 class="fw-bold text-dark mb-2"><?php echo e($tmpl->name); ?></h5>
                            <p class="text-secondary small mb-4 flex-grow-1" style="line-height: 1.5;">
                                <?php echo e($tmpl->description); ?>

                            </p>

                            <div class="pt-3 border-top d-flex align-items-center justify-content-between mt-auto">
                                <span class="text-muted small">
                                    <i class="bi bi-download me-1"></i> <?php echo e(number_format($tmpl->downloads_count)); ?> downloads
                                </span>
                                <a href="<?php echo e(route('templates.customize', $tmpl->slug)); ?>" class="btn btn-primary rounded-pill px-3 py-1.5 fw-bold shadow-sm d-flex align-items-center gap-1.5">
                                    <span>Customize & Export</span>
                                    <i class="bi bi-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Websites\Dynamic Website\Laravel First Website\PDFMasster\.PDFMaster\resources\views/templates/index.blade.php ENDPATH**/ ?>