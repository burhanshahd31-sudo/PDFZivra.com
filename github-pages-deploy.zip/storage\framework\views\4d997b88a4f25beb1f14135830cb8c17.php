<?php $__env->startSection('title', 'AI PDF Assistant'); ?>
<?php $__env->startSection('page-title', 'AI PDF Assistant & Semantic Document Q&A'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid p-0">

    <!-- Top Hero Banner -->
    <div class="card card-cust p-4 mb-4 border shadow-sm">
        <div class="d-flex align-items-center justify-content-between flex-wrap gap-3">
            <div class="d-flex align-items-center gap-3">
                <div class="p-3 rounded-4 bg-primary bg-opacity-10 text-primary">
                    <i class="bi bi-robot fs-2"></i>
                </div>
                <div>
                    <h4 class="fw-bold text-dark mb-1">VIP AI PDF Assistant</h4>
                    <p class="text-muted small mb-0">Upload any PDF contract, report, research paper, or invoice. Chat directly with your document, summarize findings, extract structured data, or translate instantly.</p>
                </div>
            </div>
            <div class="d-flex align-items-center gap-2">
                <?php
                    $prov = strtolower(\App\Models\SystemSetting::get('ai_provider', 'local'));
                    $hasKey = (bool) \App\Models\SystemSetting::get('ai_api_key');
                    $mod = \App\Models\SystemSetting::get('ai_model');
                ?>
                <?php if($prov !== 'local' && ($hasKey || in_array($prov, ['ollama', 'custom']))): ?>
                    <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 rounded-pill px-3 py-1.5 fw-bold">
                        <i class="bi bi-robot me-1"></i> <?php echo e(strtoupper($prov)); ?>: <?php echo e($mod ?: 'Active'); ?>

                    </span>
                <?php else: ?>
                    <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 rounded-pill px-3 py-1.5 fw-bold">
                        <i class="bi bi-cpu-fill me-1"></i> NLP Engine Active
                    </span>
                <?php endif; ?>
                <span class="badge bg-primary bg-opacity-10 text-primary border border-primary border-opacity-25 rounded-pill px-3 py-1.5 fw-bold">
                    <i class="bi bi-translate me-1"></i> Urdu / Multi-Lingual
                </span>
            </div>
        </div>
    </div>

    <!-- Upload Step Card (Visible when no doc uploaded) -->
    <div id="uploadCard" class="card card-cust p-5 border shadow-sm text-center mb-4">
        <div class="border-2 border-dashed rounded-4 p-5 bg-light" id="dropArea" style="cursor: pointer;" onclick="document.getElementById('docInput').click()">
            <input type="file" id="docInput" class="d-none" accept=".pdf" onchange="handleFileSelect(event)">
            <div class="p-3 rounded-circle bg-white d-inline-block shadow-sm mb-3">
                <i class="bi bi-cloud-arrow-up-fill text-primary display-4"></i>
            </div>
            <h4 class="fw-bold text-dark mb-1">Click to Upload or Drag & Drop PDF</h4>
            <p class="text-muted small mb-3">Upload legal agreements, financial statements, contracts, or books (Up to 50MB)</p>
            <button type="button" class="btn btn-primary rounded-pill px-4 py-2 fw-bold shadow-sm">
                <i class="bi bi-file-earmark-arrow-up me-1"></i> Select PDF File
            </button>
            <div id="uploadProgress" class="d-none mt-4 max-w-md mx-auto" style="max-width: 400px;">
                <div class="spinner-border text-primary spinner-border-sm mb-2" role="status"></div>
                <div class="text-primary fw-bold small">Parsing & indexing document pages...</div>
            </div>
        </div>
    </div>

    <!-- Interactive AI Assistant Workspace (Visible after upload) -->
    <div id="workspaceCard" class="d-none">
        <div class="row g-4">
            
            <!-- Left Column: Document Overview & AI Quick Actions -->
            <div class="col-lg-4">
                <div class="card card-cust p-4 border shadow-sm mb-4">
                    <div class="d-flex align-items-center justify-content-between mb-3 border-bottom pb-2">
                        <h6 class="fw-bold text-dark mb-0"><i class="bi bi-file-earmark-pdf-fill text-danger me-1"></i> Active Document</h6>
                        <button type="button" class="btn btn-xs btn-outline-secondary rounded-pill" onclick="resetDocument()">
                            <i class="bi bi-arrow-repeat me-1"></i> Switch File
                        </button>
                    </div>

                    <div class="p-3 bg-light rounded-3 mb-3">
                        <strong class="text-dark d-block text-truncate" id="docNameDisplay">Document.pdf</strong>
                        <div class="d-flex align-items-center gap-3 mt-1 small text-muted">
                            <span><i class="bi bi-files me-1"></i> <span id="docPagesDisplay">0</span> Pages</span>
                            <span><i class="bi bi-fonts me-1"></i> <span id="docWordsDisplay">0</span> Words</span>
                        </div>
                    </div>

                    <div class="mb-3">
                        <span class="text-muted small d-block mb-1 fw-semibold">Quick AI Actions:</span>
                        <div class="d-grid gap-2">
                            <button type="button" class="btn btn-sm btn-outline-primary text-start rounded-pill px-3 py-2 fw-semibold" onclick="sendAction('summarize')">
                                <i class="bi bi-file-text me-2"></i> 📄 Generate Executive Summary
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-primary text-start rounded-pill px-3 py-2 fw-semibold" onclick="sendAction('extract_entities')">
                                <i class="bi bi-search me-2"></i> 🔍 Extract Dates, Amounts & Names
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-primary text-start rounded-pill px-3 py-2 fw-semibold" onclick="sendAction('key_points')">
                                <i class="bi bi-check2-all me-2"></i> 📌 Extract Key Action Items
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-primary text-start rounded-pill px-3 py-2 fw-semibold" onclick="sendAction('explain_simple')">
                                <i class="bi bi-lightbulb me-2"></i> 💡 Explain in Simple Terms
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-success text-start rounded-pill px-3 py-2 fw-semibold" onclick="sendAction('translate', 'Urdu')">
                                <i class="bi bi-translate me-2"></i> 🌐 Translate to Urdu (اردو ترجمہ)
                            </button>
                        </div>
                    </div>

                    <!-- Export Report Form -->
                    <form id="exportForm" action="<?php echo e(route('customer.ai-assistant.export')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="doc_id" id="exportDocId">
                        <input type="hidden" name="report_content" id="exportContent">
                        <button type="button" class="btn btn-outline-dark btn-sm rounded-pill w-100 py-2 fw-bold" onclick="exportAnalysisReport()">
                            <i class="bi bi-download me-1"></i> Download AI Insights (PDF)
                        </button>
                    </form>
                </div>
            </div>

            <!-- Right Column: Interactive Chat Terminal -->
            <div class="col-lg-8">
                <div class="card card-cust border shadow-sm d-flex flex-column" style="height: 650px;">
                    <!-- Terminal Header -->
                    <div class="p-3 border-bottom d-flex align-items-center justify-content-between bg-light rounded-top">
                        <div class="d-flex align-items-center gap-2">
                            <span class="p-1.5 rounded-circle bg-success"></span>
                            <span class="fw-bold text-dark small">AI Assistant Terminal</span>
                        </div>
                        <button type="button" class="btn btn-xs btn-outline-secondary rounded-pill" onclick="clearChat()">
                            <i class="bi bi-trash me-1"></i> Clear History
                        </button>
                    </div>

                    <!-- Chat Messages Stream -->
                    <div class="flex-grow-1 p-4 overflow-auto" id="chatBox" style="background: #ffffff;">
                        <div class="d-flex gap-3 mb-3">
                            <div class="p-2 rounded-circle bg-primary bg-opacity-10 text-primary flex-shrink-0" style="width: 38px; height: 38px; display: grid; place-items: center;">
                                <i class="bi bi-robot"></i>
                            </div>
                            <div class="p-3 rounded-4 bg-light border small text-dark" style="max-width: 80%;">
                                Hello! I have processed your document. You can ask me any question about its contents, request an executive summary, or extract specific names, dates, and amounts.
                            </div>
                        </div>
                    </div>

                    <!-- Typing Indicator -->
                    <div id="typingIndicator" class="px-4 py-2 small text-muted d-none border-top bg-light">
                        <span class="spinner-grow spinner-grow-sm text-primary me-1" role="status"></span>
                        AI Assistant is analyzing the document...
                    </div>

                    <!-- Input Toolbar -->
                    <div class="p-3 border-top bg-light rounded-bottom">
                        <form id="chatForm" onsubmit="handleChatSubmit(event)">
                            <div class="input-group">
                                <input type="text" id="userInput" class="form-control rounded-pill-start border-primary px-3 shadow-none" placeholder="Ask a question about this document (e.g. What is the contract value?)..." autocomplete="off">
                                <button type="submit" class="btn btn-primary rounded-pill-end px-4 fw-bold">
                                    <i class="bi bi-send-fill me-1"></i> Ask AI
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>

</div>

<?php $__env->startPush('scripts'); ?>
<script>
    let activeDocId = null;
    let fullReportHistory = "";

    function handleFileSelect(e) {
        const file = e.target.files[0];
        if (!file) return;

        const formData = new FormData();
        formData.append('document', file);
        formData.append('_token', '<?php echo e(csrf_token()); ?>');

        document.getElementById('uploadProgress').classList.remove('d-none');

        fetch("<?php echo e(route('customer.ai-assistant.upload')); ?>", {
            method: 'POST',
            body: formData,
        })
        .then(r => r.json())
        .then(data => {
            document.getElementById('uploadProgress').classList.add('d-none');
            if (data.success) {
                activeDocId = data.doc_id;
                document.getElementById('docNameDisplay').textContent = data.name;
                document.getElementById('docPagesDisplay').textContent = data.page_count;
                document.getElementById('docWordsDisplay').textContent = Number(data.word_count).toLocaleString();

                document.getElementById('uploadCard').classList.add('d-none');
                document.getElementById('workspaceCard').classList.remove('d-none');

                appendMessage('ai', `I have indexed **${data.name}** (${data.page_count} pages). Ready for your questions!`);
            } else {
                alert(data.error || 'Failed to upload document');
            }
        })
        .catch(err => {
            document.getElementById('uploadProgress').classList.add('d-none');
            alert('Error communicating with server');
        });
    }

    function resetDocument() {
        activeDocId = null;
        document.getElementById('docInput').value = '';
        document.getElementById('uploadCard').classList.remove('d-none');
        document.getElementById('workspaceCard').classList.add('d-none');
        clearChat();
    }

    function clearChat() {
        document.getElementById('chatBox').innerHTML = '';
        fullReportHistory = "";
    }

    function appendMessage(role, text) {
        const chatBox = document.getElementById('chatBox');
        const isUser = role === 'user';

        fullReportHistory += `\n[${isUser ? 'USER' : 'AI'}]:\n${text}\n-----------------------\n`;

        const wrapper = document.createElement('div');
        wrapper.className = `d-flex gap-3 mb-3 ${isUser ? 'justify-content-end' : ''}`;

        const bubble = document.createElement('div');
        bubble.className = `p-3 rounded-4 small ${isUser ? 'bg-primary text-white' : 'bg-light border text-dark'}`;
        bubble.style.maxWidth = '85%';
        bubble.style.whiteSpace = 'pre-wrap';
        bubble.textContent = text;

        if (!isUser) {
            const icon = document.createElement('div');
            icon.className = 'p-2 rounded-circle bg-primary bg-opacity-10 text-primary flex-shrink-0';
            icon.style.width = '38px';
            icon.style.height = '38px';
            icon.style.display = 'grid';
            icon.style.placeItems = 'center';
            icon.innerHTML = '<i class="bi bi-robot"></i>';
            wrapper.appendChild(icon);
        }

        wrapper.appendChild(bubble);
        chatBox.appendChild(wrapper);
        chatBox.scrollTop = chatBox.scrollHeight;
    }

    function sendAction(actionType, targetLang = '') {
        if (!activeDocId) return;

        const actionPrompts = {
            'summarize': 'Please generate a comprehensive executive summary of this document.',
            'extract_entities': 'Please extract all dates, monetary amounts, names, and contact details from this document.',
            'key_points': 'Please extract the key takeaways and actionable bullet points from this document.',
            'explain_simple': 'Please explain the core purpose of this document in simple, easy-to-understand language.',
            'translate': 'Please translate the core contents and summary of this document to Urdu.'
        };

        const msg = actionPrompts[actionType] || actionType;
        appendMessage('user', msg);
        executeAiRequest(msg, actionType, targetLang);
    }

    function handleChatSubmit(e) {
        e.preventDefault();
        const input = document.getElementById('userInput');
        const text = input.value.trim();
        if (!text || !activeDocId) return;

        appendMessage('user', text);
        input.value = '';
        executeAiRequest(text, 'chat');
    }

    function executeAiRequest(message, action = 'chat', targetLang = 'English') {
        const indicator = document.getElementById('typingIndicator');
        if (indicator) indicator.classList.remove('d-none');

        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '<?php echo e(csrf_token()); ?>';

        fetch("<?php echo e(route('customer.ai-assistant.chat')); ?>", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-TOKEN': csrfToken
            },
            body: JSON.stringify({
                doc_id: activeDocId,
                message: message,
                action: action,
                target_lang: targetLang || 'English'
            })
        })
        .then(async r => {
            const data = await r.json().catch(() => null);
            if (indicator) indicator.classList.add('d-none');

            if (r.status === 419) {
                appendMessage('ai', 'Your session has expired. Please refresh the page to continue chatting with this document.');
                return;
            }

            if (r.ok && data && data.success) {
                appendMessage('ai', data.reply);
            } else {
                const errMsg = (data && (data.reply || data.error || data.message)) 
                    ? (data.reply || data.error || data.message) 
                    : 'The analysis assistant is processing. Please try asking again in a moment.';
                appendMessage('ai', errMsg);
            }
        })
        .catch(err => {
            if (indicator) indicator.classList.add('d-none');
            console.error('AI chat error:', err);
            appendMessage('ai', 'Unable to reach the server. Please check your internet connection or reload the page.');
        });
    }

    function exportAnalysisReport() {
        if (!activeDocId || !fullReportHistory) {
            alert('Please interact with the document first before exporting the analysis report.');
            return;
        }

        document.getElementById('exportDocId').value = activeDocId;
        document.getElementById('exportContent').value = fullReportHistory;
        document.getElementById('exportForm').submit();
    }
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.customer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Websites\Dynamic Website\Laravel First Website\PDFMasster\.PDFMaster\resources\views/customer/ai_assistant.blade.php ENDPATH**/ ?>