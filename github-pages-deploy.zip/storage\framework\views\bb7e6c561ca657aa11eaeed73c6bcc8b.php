<?php $__env->startSection('title', 'PDF Master — Everything You Need to Work With PDFs'); ?>

<?php $__env->startSection('content'); ?>

<!-- Hero Section Matching Reference Panel 1 -->
<section class="py-5 position-relative overflow-hidden" style="background: linear-gradient(180deg, #f8fafc 0%, #ffffff 100%);">
    <div class="container py-lg-4">
        <div class="row align-items-center g-5">
            <!-- Left Column: Headline & Upload Dropzone -->
            <div class="col-lg-6 text-center text-lg-start">
                <h1 class="display-4 fw-extrabold text-dark tracking-tight mb-3" style="line-height: 1.15; font-size: 2.85rem;">
                    Everything You Need to Work With PDFs
                </h1>

                <p class="lead text-muted mb-4" style="font-size: 1.05rem; line-height: 1.6;">
                    Edit, Convert, Compress, Sign and Manage Your PDF Documents in One Place.
                </p>

                <!-- Compact Upload Box Matching Image -->
                <div class="card p-4 text-center border-2 border-dashed rounded-4 position-relative mx-auto mx-lg-0" style="max-width: 440px; border-color: #93c5fd; background: #ffffff; box-shadow: 0 10px 30px rgba(37, 99, 235, 0.06);">
                    <div class="mb-2">
                        <div class="d-inline-flex align-items-center justify-content-center bg-primary bg-opacity-10 text-primary rounded-circle mb-2" style="width: 54px; height: 54px;">
                            <i class="bi bi-cloud-arrow-up-fill fs-2"></i>
                        </div>
                        <h6 class="fw-bold mb-1 text-dark">Drop & Choose your PDF here</h6>
                        <p class="text-muted small mb-3">Supports PDF up to 25MB</p>
                    </div>

                    <div class="d-flex justify-content-center gap-2">
                        <a href="<?php echo e(route('tool.show', 'merge-pdf')); ?>" class="btn btn-pm-blue px-4 py-2">
                            Select PDF
                        </a>
                    </div>
                </div>
            </div>

            <!-- Right Column: 3D Laptop & Floating PDF Illustration -->
            <div class="col-lg-6 text-center">
                <img src="<?php echo e(asset('assets/images/hero-pdf-illustration.svg')); ?>" alt="PDF Master Workflow" class="img-fluid" style="max-height: 420px; filter: drop-shadow(0 20px 30px rgba(0,0,0,0.08));">
            </div>
        </div>
    </div>
</section>

<!-- Popular Tools Row Matching Panel 1 -->
<section class="py-4 border-top border-bottom bg-white">
    <div class="container">
        <h6 class="fw-bold text-dark text-uppercase small tracking-wider mb-3">Popular Tools</h6>
        
        <div class="row g-3">
            <div class="col-6 col-sm-4 col-md-2">
                <a href="<?php echo e(route('tool.show', 'merge-pdf')); ?>" class="card card-saas p-3 text-center text-decoration-none h-100">
                    <div class="p-2 rounded-3 text-white mx-auto mb-2" style="background-color: #ef4444; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center;">
                        <i class="bi bi-files fs-5"></i>
                    </div>
                    <span class="small fw-bold text-dark">Merge PDF</span>
                </a>
            </div>

            <div class="col-6 col-sm-4 col-md-2">
                <a href="<?php echo e(route('tool.show', 'compress-pdf')); ?>" class="card card-saas p-3 text-center text-decoration-none h-100">
                    <div class="p-2 rounded-3 text-white mx-auto mb-2" style="background-color: #f59e0b; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center;">
                        <i class="bi bi-file-earmark-zip fs-5"></i>
                    </div>
                    <span class="small fw-bold text-dark">Compress PDF</span>
                </a>
            </div>

            <div class="col-6 col-sm-4 col-md-2">
                <a href="<?php echo e(route('tool.show', 'edit-pdf')); ?>" class="card card-saas p-3 text-center text-decoration-none h-100">
                    <div class="p-2 rounded-3 text-white mx-auto mb-2" style="background-color: #2563eb; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center;">
                        <i class="bi bi-pencil fs-5"></i>
                    </div>
                    <span class="small fw-bold text-dark">Edit PDF</span>
                </a>
            </div>

            <div class="col-6 col-sm-4 col-md-2">
                <a href="<?php echo e(route('tool.show', 'pdf-to-word')); ?>" class="card card-saas p-3 text-center text-decoration-none h-100">
                    <div class="p-2 rounded-3 text-white mx-auto mb-2" style="background-color: #4f46e5; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center;">
                        <i class="bi bi-filetype-docx fs-5"></i>
                    </div>
                    <span class="small fw-bold text-dark">PDF to Word</span>
                </a>
            </div>

            <div class="col-6 col-sm-4 col-md-2">
                <a href="<?php echo e(route('tool.show', 'sign-pdf')); ?>" class="card card-saas p-3 text-center text-decoration-none h-100">
                    <div class="p-2 rounded-3 text-white mx-auto mb-2" style="background-color: #10b981; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center;">
                        <i class="bi bi-pen fs-5"></i>
                    </div>
                    <span class="small fw-bold text-dark">Sign PDF</span>
                </a>
            </div>

            <div class="col-6 col-sm-4 col-md-2">
                <a href="<?php echo e(route('tool.show', 'pdf-to-jpg')); ?>" class="card card-saas p-3 text-center text-decoration-none h-100">
                    <div class="p-2 rounded-3 text-white mx-auto mb-2" style="background-color: #06b6d4; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center;">
                        <i class="bi bi-filetype-jpg fs-5"></i>
                    </div>
                    <span class="small fw-bold text-dark">PDF to JPG</span>
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Interactive PDF Tools Suite & Filter Section -->
<section class="py-5 bg-white border-bottom" id="homeToolsSection">
    <div class="container">
        <div class="text-center mb-4" style="max-width: 760px; margin: 0 auto;">
            <span class="badge bg-primary bg-opacity-10 text-primary px-3 py-1.5 rounded-pill fw-bold mb-2">
                <i class="bi bi-stars me-1"></i> Complete Online PDF Suite
            </span>
            <h2 class="fw-extrabold text-dark mb-2">Work Faster with 68+ PDF Tools</h2>
            <p class="text-muted small mb-3">Search, filter, or choose any tool below to convert, merge, edit, compress, or sign documents.</p>

            <!-- Real-time Search Box -->
            <div class="input-group input-group-lg shadow-sm border rounded-pill overflow-hidden bg-white p-1 mb-3">
                <span class="input-group-text bg-transparent border-0 ps-3 pe-2"><i class="bi bi-search text-primary"></i></span>
                <input type="text" 
                       id="homeToolsSearchInput" 
                       class="form-control border-0 shadow-none ps-1 fs-6" 
                       placeholder="Filter tools instantly (e.g. merge, compress, word, jpg, split, sign)..." 
                       autocomplete="off">
                <button type="button" id="homeClearSearchBtn" class="btn btn-link text-muted pe-2 text-decoration-none d-none" title="Clear Search">
                    <i class="bi bi-x-circle-fill fs-5"></i>
                </button>
            </div>

            <!-- Horizontal Scrollable Category Filter Pills -->
            <div class="d-flex gap-2 justify-content-start justify-content-md-center overflow-x-auto py-1 px-1 custom-scrollbar text-nowrap" id="homeCategoryPills">
                <button type="button" class="btn btn-sm home-cat-pill btn-primary text-white fw-bold shadow-sm active rounded-pill px-3 py-1.5 flex-shrink-0" data-category="all">
                    <i class="bi bi-grid-fill me-1"></i> All Tools
                </button>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button type="button" class="btn btn-sm home-cat-pill btn-outline-secondary rounded-pill px-3 py-1.5 flex-shrink-0" data-category="<?php echo e($cat->slug); ?>">
                        <i class="bi <?php echo e($cat->icon ?? 'bi-folder'); ?> me-1"></i> <?php echo e($cat->name); ?>

                        <span class="badge bg-secondary bg-opacity-25 text-dark ms-1" style="font-size: 0.70rem;"><?php echo e($cat->tools->count()); ?></span>
                    </button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('forms.index')); ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3 py-1.5 fw-semibold flex-shrink-0">
                    <i class="bi bi-ui-checks me-1"></i> PDF Forms (53+)
                </a>
            </div>

            <!-- Live Match Count Indicator -->
            <div id="homeActiveFilterBar" class="d-flex align-items-center justify-content-center gap-2 mt-3 small text-muted">
                <span>Showing <strong id="homeVisibleToolsCount" class="text-primary fw-bold">68</strong> tools</span>
                <button type="button" id="homeResetAllBtn" class="btn btn-sm btn-outline-danger rounded-pill px-2.5 py-0.5 d-none" style="font-size: 0.72rem;">
                    <i class="bi bi-x-lg me-1"></i> Reset
                </button>
            </div>
        </div>

        <!-- No Results Notice -->
        <div id="homeNoToolsNotice" class="text-center py-5 d-none">
            <div class="p-4 rounded-4 bg-light border d-inline-block text-center" style="max-width: 450px;">
                <div class="p-3 rounded-circle bg-primary bg-opacity-10 text-primary d-inline-flex fs-2 mb-2">
                    <i class="bi bi-search"></i>
                </div>
                <h6 class="fw-bold text-dark mb-1">No Matching Tools Found</h6>
                <p class="text-muted small mb-3">Try different keywords or reset your filter.</p>
                <button type="button" id="homeNoResultsResetBtn" class="btn btn-sm btn-primary rounded-pill px-4">
                    Browse All Tools
                </button>
            </div>
        </div>

        <!-- Categorized Tools Grid -->
        <div id="homeToolsContainer">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mb-5 home-category-block" data-category-slug="<?php echo e($category->slug); ?>">
                    <div class="d-flex align-items-center justify-content-between mb-3 border-bottom pb-2">
                        <h5 class="fw-bold text-dark mb-0 d-flex align-items-center gap-2">
                            <i class="bi <?php echo e($category->icon ?? 'bi-folder'); ?> text-primary"></i>
                            <span><?php echo e($category->name); ?></span>
                        </h5>
                        <div class="d-flex align-items-center gap-2">
                            <span class="badge bg-light text-muted border rounded-pill px-2.5 py-1">
                                <span class="home-cat-count"><?php echo e($category->tools->count()); ?></span> tools
                            </span>
                            <a href="<?php echo e(route('tools.category', $category->slug)); ?>" class="small fw-semibold text-primary text-decoration-none ms-1">
                                View Suite &rarr;
                            </a>
                        </div>
                    </div>

                    <div class="row g-3">
                        <?php $__currentLoopData = $category->tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-6 col-md-4 col-lg-3 home-tool-item" 
                                 data-tool-name="<?php echo e(strtolower($tool->name)); ?>" 
                                 data-tool-desc="<?php echo e(strtolower($tool->description)); ?>" 
                                 data-tool-slug="<?php echo e($tool->slug); ?>"
                                 data-category="<?php echo e($category->slug); ?>">
                                <a href="<?php echo e(route('tool.show', $tool->slug)); ?>" class="tool-card h-100">
                                    <div class="d-flex align-items-start justify-content-between mb-2">
                                        <div class="tool-card-icon" style="background-color: <?php echo e($tool->color); ?>; width: 38px; height: 38px; font-size: 1.1rem;">
                                            <i class="bi <?php echo e($tool->icon); ?>"></i>
                                        </div>
                                        <?php if($tool->is_pro_only): ?>
                                            <span class="badge bg-warning text-dark px-2 py-0.5" style="font-size: 0.65rem; font-weight: 700;">PRO</span>
                                        <?php endif; ?>
                                    </div>
                                    <h6 class="tool-card-title text-dark fw-bold mb-1" style="font-size: 0.95rem;"><?php echo e($tool->name); ?></h6>
                                    <p class="tool-card-desc text-muted small mb-3" style="font-size: 0.8rem; line-height: 1.4;">
                                        <?php echo e($tool->description); ?>

                                    </p>
                                    <div class="tool-card-footer mt-auto pt-2 border-top d-flex align-items-center justify-content-between">
                                        <span class="tool-card-open small text-primary fw-bold">Open <i class="bi bi-arrow-right"></i></span>
                                        <span class="badge rounded-pill bg-light text-muted border fw-normal" style="font-size: 0.70rem;"><?php echo e($tool->max_file_size_mb); ?>MB</span>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<!-- Tool Categories Grid Matching Panel 1 -->
<section class="py-5" style="background-color: #f8fafc;">
    <div class="container">
        <h6 class="fw-bold text-dark text-uppercase small tracking-wider mb-4">Tool Categories</h6>

        <div class="row g-4">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-4">
                <div class="card card-saas p-4 h-100 border">
                    <div class="d-flex align-items-center gap-3 mb-3">
                        <div class="p-2 rounded-3 bg-primary bg-opacity-10 text-primary fs-4" style="width: 44px; height: 44px; display: flex; align-items: center; justify-content: center;">
                            <i class="bi <?php echo e($cat->icon); ?>"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold mb-0 text-dark"><?php echo e($cat->name); ?></h5>
                            <span class="text-muted small"><?php echo e($cat->tools->count()); ?> Tools Available</span>
                        </div>
                    </div>
                    <p class="text-muted small mb-4 line-clamp-2" style="min-height: 40px;">
                        <?php echo e($cat->description); ?>

                    </p>
                    <div class="mt-auto">
                        <a href="<?php echo e(route('tools.category', $cat->slug)); ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3">
                            Explore <?php echo e($cat->name); ?> &rarr;
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <!-- Dedicated Forms Center Category Tile -->
            <div class="col-md-6 col-lg-4">
                <div class="card card-saas p-4 h-100 border bg-primary bg-opacity-10 border-primary border-opacity-25">
                    <div class="d-flex align-items-center gap-3 mb-3">
                        <div class="p-2 rounded-3 bg-primary text-white fs-4" style="width: 44px; height: 44px; display: flex; align-items: center; justify-content: center;">
                            <i class="bi bi-ui-checks"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold mb-0 text-dark">PDF Forms Center</h5>
                            <span class="text-primary small fw-semibold">15 Official IRS & Gov Forms</span>
                        </div>
                    </div>
                    <p class="text-muted small mb-4">
                        Fill, sign, validate, and download official US government forms (W-9, 1040, I-9, DS-11) online.
                    </p>
                    <div class="mt-auto">
                        <a href="<?php echo e(route('forms.index')); ?>" class="btn btn-sm btn-pm-blue px-3">
                            Open Forms Center &rarr;
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="text-center mt-5">
            <a href="<?php echo e(route('tools.index')); ?>" class="btn btn-pm-blue px-5 py-2">
                View All PDF Tools &rarr;
            </a>
        </div>
    </div>
</section>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const searchInput = document.getElementById('homeToolsSearchInput');
    const clearBtn = document.getElementById('homeClearSearchBtn');
    const pills = document.querySelectorAll('.home-cat-pill');
    const categoryBlocks = document.querySelectorAll('.home-category-block');
    const visibleCountBadge = document.getElementById('homeVisibleToolsCount');
    const resetBtn = document.getElementById('homeResetAllBtn');
    const noResultsResetBtn = document.getElementById('homeNoResultsResetBtn');
    const noToolsNotice = document.getElementById('homeNoToolsNotice');

    let activeCategory = 'all';

    function runHomeFilter() {
        const query = searchInput ? searchInput.value.trim().toLowerCase() : '';
        let totalVisible = 0;

        if (clearBtn) {
            if (query.length > 0) {
                clearBtn.classList.remove('d-none');
            } else {
                clearBtn.classList.add('d-none');
            }
        }

        categoryBlocks.forEach(block => {
            const blockSlug = block.getAttribute('data-category-slug');
            const isCatMatch = (activeCategory === 'all' || blockSlug === activeCategory);

            if (!isCatMatch) {
                block.classList.add('d-none');
                return;
            }

            let catVisible = 0;
            const toolItems = block.querySelectorAll('.home-tool-item');

            toolItems.forEach(item => {
                const name = item.getAttribute('data-tool-name') || '';
                const desc = item.getAttribute('data-tool-desc') || '';
                const slug = item.getAttribute('data-tool-slug') || '';

                if (!query || name.includes(query) || desc.includes(query) || slug.includes(query)) {
                    item.classList.remove('d-none');
                    catVisible++;
                    totalVisible++;
                } else {
                    item.classList.add('d-none');
                }
            });

            const countSpan = block.querySelector('.home-cat-count');
            if (countSpan) countSpan.textContent = catVisible;

            if (catVisible > 0) {
                block.classList.remove('d-none');
            } else {
                block.classList.add('d-none');
            }
        });

        if (visibleCountBadge) visibleCountBadge.textContent = totalVisible;

        // Update Pill UI
        pills.forEach(pill => {
            const pCat = pill.getAttribute('data-category');
            const badge = pill.querySelector('.badge');
            if (pCat === activeCategory) {
                pill.className = 'btn btn-sm home-cat-pill btn-primary text-white fw-bold shadow-sm active rounded-pill px-3 py-1.5 flex-shrink-0';
                if (badge) badge.className = 'badge bg-white text-primary ms-1';
            } else {
                pill.className = 'btn btn-sm home-cat-pill btn-outline-secondary rounded-pill px-3 py-1.5 flex-shrink-0';
                if (badge) badge.className = 'badge bg-secondary bg-opacity-25 text-dark ms-1';
            }
        });

        // Toggle reset button
        if (resetBtn) {
            if (activeCategory !== 'all' || query.length > 0) {
                resetBtn.classList.remove('d-none');
            } else {
                resetBtn.classList.add('d-none');
            }
        }

        // Toggle no results notice
        if (noToolsNotice) {
            if (totalVisible === 0) {
                noToolsNotice.classList.remove('d-none');
            } else {
                noToolsNotice.classList.add('d-none');
            }
        }
    }

    pills.forEach(pill => {
        pill.addEventListener('click', function () {
            activeCategory = this.getAttribute('data-category') || 'all';
            runHomeFilter();
        });
    });

    if (searchInput) {
        searchInput.addEventListener('input', runHomeFilter);
    }

    if (clearBtn) {
        clearBtn.addEventListener('click', function () {
            if (searchInput) searchInput.value = '';
            runHomeFilter();
        });
    }

    function resetHomeFilters() {
        activeCategory = 'all';
        if (searchInput) searchInput.value = '';
        runHomeFilter();
    }

    if (resetBtn) resetBtn.addEventListener('click', resetHomeFilters);
    if (noResultsResetBtn) noResultsResetBtn.addEventListener('click', resetHomeFilters);

    runHomeFilter();
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Websites\Dynamic Website\Laravel First Website\PDFMasster\.PDFMaster\resources\views/home/index.blade.php ENDPATH**/ ?>