<?php $__env->startSection('title', $tool->name . ' — Free Online Tool | ' . ($siteName ?? \App\Models\SystemSetting::get('site_name', 'PDF Master'))); ?>
<?php $__env->startSection('meta_description', $tool->meta_description ?? $tool->description); ?>

<?php $__env->startSection('content'); ?>
<div class="py-5" style="background-color: #f8fafc;">
    <div class="container py-lg-2">

        <div class="row g-4">
            <!-- Left / Center Workspace (70% Width) -->
            <div class="col-lg-8">
                <!-- Tool Title Header Banner -->
                <div class="d-flex align-items-center gap-3 mb-4">
                    <div class="p-2 rounded-3 text-white" style="background-color: <?php echo e($tool->color); ?>; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center;">
                        <i class="bi <?php echo e($tool->icon); ?> fs-4"></i>
                    </div>
                    <div>
                        <h4 class="fw-bold mb-0 text-dark"><?php echo e($tool->name); ?></h4>
                        <p class="text-muted small mb-0"><?php echo e($tool->description); ?></p>
                    </div>
                </div>

                <?php if(auth()->guard()->guest()): ?>
                <!-- Guest Notice Banner -->
                <?php if(($guestOpsRemaining ?? 0) > 0): ?>
                <div class="alert alert-info border-0 rounded-4 p-3 mb-4 d-flex align-items-center justify-content-between flex-wrap gap-3 shadow-sm" style="background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%); border-left: 5px solid #2563eb !important;">
                    <div class="d-flex align-items-center gap-3">
                        <div class="p-2 rounded-circle bg-primary text-white">
                            <i class="bi bi-lightning-charge-fill fs-4"></i>
                        </div>
                        <div>
                            <strong class="text-dark d-block">Free Guest Mode: <?php echo e($guestOpsRemaining); ?> of <?php echo e($maxGuestOps ?? 3); ?> operations remaining today</strong>
                            <span class="text-secondary small">You can process documents right now! Sign in anytime to unlock 5 daily free operations and cloud history.</span>
                        </div>
                    </div>
                    <div class="d-flex gap-2">
                        <a href="<?php echo e(route('login')); ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3">Login</a>
                        <a href="<?php echo e(route('register')); ?>" class="btn btn-sm btn-primary rounded-pill px-3 fw-bold">Sign Up to Free Trial</a>
                    </div>
                </div>
                <?php else: ?>
                <div class="alert alert-warning border-0 rounded-4 p-3 mb-4 d-flex align-items-center justify-content-between flex-wrap gap-3 shadow-sm">
                    <div class="d-flex align-items-center gap-3">
                        <div class="p-2 rounded-circle bg-warning text-dark">
                            <i class="bi bi-exclamation-triangle-fill fs-4"></i>
                        </div>
                        <div>
                            <strong class="text-dark d-block">Daily Guest Limit Reached (<?php echo e($maxGuestOps ?? 3); ?>/<?php echo e($maxGuestOps ?? 3); ?>)</strong>
                            <span class="text-secondary small">Please create an account or log in to keep processing your documents!</span>
                        </div>
                    </div>
                    <div class="d-flex gap-2">
                        <a href="<?php echo e(route('login')); ?>" class="btn btn-sm btn-outline-dark rounded-pill px-3">Login</a>
                        <a href="<?php echo e(route('register')); ?>" class="btn btn-sm btn-primary rounded-pill px-3 fw-bold">Sign Up to Free Trial</a>
                    </div>
                </div>
                <?php endif; ?>
                <?php endif; ?>

                <!-- Main Tool Card -->
                <div class="card card-saas p-4 p-md-5 mb-4" id="toolWorkspaceCard">
                    <!-- Stage 1: Upload Dropzone Matching Reference Panels 3, 4, 5, 6 -->
                    <div id="dropzoneStage">
                        <div class="border-2 border-dashed rounded-4 p-5 text-center position-relative" style="border-color: #93c5fd; background: #ffffff; cursor: pointer;">
                            <input type="file" id="toolFileInput" class="position-absolute top-0 start-0 w-100 h-100 opacity-0" style="cursor: pointer;" multiple>
                            
                            <div class="mb-2">
                                <div class="d-inline-flex align-items-center justify-content-center bg-primary bg-opacity-10 text-primary rounded-circle mb-3" style="width: 60px; height: 60px;">
                                    <i class="bi <?php echo e(in_array($tool->slug, ['jpg-to-pdf', 'png-to-pdf', 'images-to-pdf', 'jpeg-to-pdf', 'webp-to-pdf', 'extract-images']) ? 'bi-images' : 'bi-cloud-arrow-up-fill'); ?> fs-1"></i>
                                </div>
                                <?php if(in_array($tool->slug, ['jpg-to-pdf', 'png-to-pdf', 'images-to-pdf', 'jpeg-to-pdf', 'webp-to-pdf'])): ?>
                                    <h5 class="fw-bold mb-1 text-dark">Drop & Choose your Image here</h5>
                                    <p class="text-muted small mb-3">Supports JPG, PNG, WEBP, BMP up to <?php echo e($maxSizeMb); ?>MB (Single or Batch Upload)</p>
                                    <button type="button" class="btn btn-pm-blue px-4 py-2">Select Images</button>
                                <?php else: ?>
                                    <h5 class="fw-bold mb-1 text-dark">Drop & Choose your file(s) here</h5>
                                    <p class="text-muted small mb-3">Supports single file or batch multi-file processing up to <?php echo e($maxSizeMb); ?>MB</p>
                                    <button type="button" class="btn btn-pm-blue px-4 py-2">Select Documents (Single or Batch)</button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Stage 2: Selected File Info & Advanced Options (Revealed on select or always ready) -->
                    <div id="optionsStage" class="d-none mt-4">
                        <!-- Selected file pill -->
                        <div class="p-3 bg-light rounded-3 border mb-4 d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center gap-3">
                                <div>
                                    <i class="bi bi-file-earmark-pdf-fill text-danger fs-3" id="filePillPdfIcon"></i>
                                    <img id="imagePreviewThumb" src="" alt="preview" class="rounded border d-none" style="width: 48px; height: 48px; object-fit: cover;">
                                </div>
                                <div>
                                    <div class="fw-bold text-dark text-truncate" id="filePillName" style="max-width: 380px;">file.pdf</div>
                                    <div class="small text-muted" id="filePillSize">0 KB</div>
                                </div>
                            </div>
                            <button type="button" class="btn btn-sm btn-outline-danger rounded-pill px-3" onclick="resetFileSelection()">
                                <i class="bi bi-x me-1"></i> Remove
                            </button>
                        </div>

                        <!-- Advanced Options Box Matching Reference Panels -->
                        <div class="card p-3 border rounded-3 mb-4 bg-white">
                            <h6 class="fw-bold mb-3 text-dark">Options for <?php echo e($tool->name); ?></h6>

                            <?php if($tool->slug === 'compress-pdf'): ?>
                                <!-- Compression Level -->
                                <label class="form-label fw-semibold small text-dark">Compression Level</label>
                                <div class="mb-3">
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="radio" name="compression_level" id="cHigh" value="high">
                                        <label class="form-check-label small" for="cHigh">
                                            High Compression (Smallest Size)
                                        </label>
                                    </div>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="radio" name="compression_level" id="cMed" value="medium" checked>
                                        <label class="form-check-label small fw-bold text-primary" for="cMed">
                                            Recommended (Medium Quality)
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="compression_level" id="cLow" value="low">
                                        <label class="form-check-label small" for="cLow">
                                            Low Compression (Best Quality)
                                        </label>
                                    </div>
                                </div>

                            <?php elseif(in_array($tool->slug, ['rotate-pdf'])): ?>
                                <label class="form-label fw-semibold small text-dark">Rotation Angle</label>
                                <div class="row g-2 mb-3">
                                    <div class="col-4">
                                        <input type="radio" class="btn-check" name="degrees" id="deg90" value="90" checked>
                                        <label class="btn btn-outline-primary w-100 py-2 small" for="deg90"><i class="bi bi-arrow-clockwise me-1"></i> 90° Right</label>
                                    </div>
                                    <div class="col-4">
                                        <input type="radio" class="btn-check" name="degrees" id="deg180" value="180">
                                        <label class="btn btn-outline-primary w-100 py-2 small" for="deg180"><i class="bi bi-arrow-repeat me-1"></i> 180° Half</label>
                                    </div>
                                    <div class="col-4">
                                        <input type="radio" class="btn-check" name="degrees" id="deg270" value="270">
                                        <label class="btn btn-outline-primary w-100 py-2 small" for="deg270"><i class="bi bi-arrow-counterclockwise me-1"></i> 270° Left</label>
                                    </div>
                                </div>

                            <?php elseif(in_array($tool->slug, ['add-watermark'])): ?>
                                <label class="form-label fw-semibold small text-dark">Watermark Text</label>
                                <input type="text" id="watermarkTextInput" class="form-control mb-3" placeholder="e.g. CONFIDENTIAL, DRAFT, COPY" value="CONFIDENTIAL">

                            <?php elseif(in_array($tool->slug, ['remove-watermark'])): ?>
                                <div class="p-3 bg-light rounded-3 mb-3 border">
                                    <h6 class="fw-bold text-dark mb-1"><i class="bi bi-eraser text-warning me-1"></i> Clean Watermark & Overlays</h6>
                                    <p class="text-muted small mb-0">Our engine scans and neutralizes common watermark overlays while preserving high-fidelity vector and text layouts.</p>
                                </div>

                            <?php elseif(in_array($tool->slug, ['add-header-footer'])): ?>
                                <div class="row g-2 mb-3">
                                    <div class="col-6">
                                        <label class="form-label fw-semibold small text-dark">Running Header Text</label>
                                        <input type="text" id="headerTextInput" class="form-control" placeholder="Header (e.g. Company Confidential)" value="<?php echo e(($siteName ?? \App\Models\SystemSetting::get('site_name', 'PDF Master'))); ?> Document">
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label fw-semibold small text-dark">Running Footer Text</label>
                                        <input type="text" id="footerTextInput" class="form-control" placeholder="Footer text" value="Page {PAGE} of {TOTAL}">
                                    </div>
                                </div>

                            <?php elseif(in_array($tool->slug, ['pdf-metadata-editor'])): ?>
                                <div class="row g-2 mb-3">
                                    <div class="col-6">
                                        <label class="form-label fw-semibold small text-dark">Document Title</label>
                                        <input type="text" id="metaTitleInput" class="form-control" placeholder="Document Title" value="Official Document">
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label fw-semibold small text-dark">Author / Organization</label>
                                        <input type="text" id="metaAuthorInput" class="form-control" placeholder="Author" value="<?php echo e(auth()->user()?->name ?? (($siteName ?? \App\Models\SystemSetting::get('site_name', 'PDF Master')) . ' Team')); ?>">
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label fw-semibold small text-dark">Subject / Classification</label>
                                        <input type="text" id="metaSubjectInput" class="form-control" placeholder="Subject" value="Business Report">
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label fw-semibold small text-dark">Keywords (Tags)</label>
                                        <input type="text" id="metaKeywordsInput" class="form-control" placeholder="pdf, report, official" value="pdf, report">
                                    </div>
                                </div>

                            <?php elseif(in_array($tool->slug, ['extract-images'])): ?>
                                <div class="p-3 bg-light rounded-3 mb-3 border">
                                    <h6 class="fw-bold text-dark mb-1"><i class="bi bi-images text-success me-1"></i> Extract High-Resolution Images</h6>
                                    <p class="text-muted small mb-0">All photos, embedded logos, diagrams, and scans inside this PDF will be extracted and bundled into a downloadable ZIP archive.</p>
                                </div>

                            <?php elseif(in_array($tool->slug, ['ai-pdf-summary'])): ?>
                                <div class="p-3 bg-primary bg-opacity-10 rounded-3 mb-3 border border-primary border-opacity-25">
                                    <h6 class="fw-bold text-primary mb-1"><i class="bi bi-stars me-1"></i> AI Semantic Analysis & Executive Briefing</h6>
                                    <p class="text-secondary small mb-0">Our AI parsing engine indexes document nodes, key takeaways, and structural elements to generate a clean, formatted Executive Brief PDF.</p>
                                </div>

                            <?php elseif(in_array($tool->slug, ['add-page-numbers'])): ?>
                                <label class="form-label fw-semibold small text-dark">Numbering Format</label>
                                <select class="form-select mb-3" id="pageFormatSelect">
                                    <option value="Page {PAGE} of {TOTAL}" selected>Page {PAGE} of {TOTAL} (e.g. Page 1 of 5)</option>
                                    <option value="{PAGE} / {TOTAL}">{PAGE} / {TOTAL} (e.g. 1 / 5)</option>
                                    <option value="Page {PAGE}">Page {PAGE} (e.g. Page 1)</option>
                                    <option value="- {PAGE} -">- {PAGE} - (e.g. - 1 -)</option>
                                </select>

                            <?php elseif(in_array($tool->slug, ['split-pdf', 'split-by-range', 'extract-pages', 'extract-pdf-pages'])): ?>
                                <label class="form-label fw-semibold small text-dark">Page Range to Extract</label>
                                <input type="text" id="pageRangeInput" class="form-control mb-2" placeholder="e.g. 1, 3-5, 8" value="1">
                                <div class="form-text small mb-3">Specify individual pages separated by commas, or page ranges with a hyphen.</div>

                            <?php elseif(in_array($tool->slug, ['delete-pdf-pages', 'remove-pages'])): ?>
                                <label class="form-label fw-semibold small text-dark">Pages to Delete</label>
                                <input type="text" id="pagesToDeleteInput" class="form-control mb-2" placeholder="e.g. 1, 3, 5" value="1">
                                <div class="form-text small mb-3">List the page numbers you want removed from the document.</div>

                            <?php elseif(in_array($tool->slug, ['reorder-pdf-pages', 'rearrange-pages', 'organize-pdf'])): ?>
                                <label class="form-label fw-semibold small text-dark">New Page Order Sequence</label>
                                <input type="text" id="pageOrderInput" class="form-control mb-2" placeholder="e.g. 3, 1, 2" value="2, 1">
                                <div class="form-text small mb-3">Enter the new sequence order of pages separated by commas.</div>

                            <?php elseif(in_array($tool->slug, ['duplicate-pages'])): ?>
                                <label class="form-label fw-semibold small text-dark">Pages to Duplicate</label>
                                <input type="text" id="duplicatePagesInput" class="form-control mb-2" placeholder="e.g. 1, 2" value="1">

                            <?php elseif(in_array($tool->slug, ['crop-pdf'])): ?>
                                <label class="form-label fw-semibold small text-dark">Crop Margin (All Sides)</label>
                                <select class="form-select mb-3" id="cropMarginSelect">
                                    <option value="10">10 mm — Subtle Margin Trim</option>
                                    <option value="15" selected>15 mm — Standard Crop</option>
                                    <option value="25">25 mm — Deep Margin Crop</option>
                                </select>

                            <?php elseif(in_array($tool->slug, ['add-text-to-pdf'])): ?>
                                <div class="row g-2 mb-3">
                                    <div class="col-8">
                                        <label class="form-label fw-semibold small text-dark">Custom Text to Add</label>
                                        <input type="text" id="addTextInput" class="form-control" placeholder="Enter text to stamp on PDF" value="APPROVED">
                                    </div>
                                    <div class="col-4">
                                        <label class="form-label fw-semibold small text-dark">Font Size</label>
                                        <select class="form-select" id="fontSizeSelect">
                                            <option value="12">12 pt (Small)</option>
                                            <option value="16" selected>16 pt (Medium)</option>
                                            <option value="22">22 pt (Large)</option>
                                        </select>
                                    </div>
                                </div>

                            <?php elseif(in_array($tool->slug, ['protect-pdf', 'set-pdf-password', 'encrypt-pdf'])): ?>
                                <label class="form-label fw-semibold small text-dark">Document Encryption Password</label>
                                <input type="password" id="pdfPasswordInput" class="form-control mb-3" placeholder="Enter secure password" value="password123">

                            <?php elseif(in_array($tool->slug, ['unlock-pdf', 'remove-password'])): ?>
                                <label class="form-label fw-semibold small text-dark">Current Document Password (if required)</label>
                                <input type="password" id="pdfPasswordInput" class="form-control mb-3" placeholder="Leave blank if standard protection">

                            <?php elseif(in_array($tool->slug, ['pdf-to-word', 'pdf-to-docx', 'conversion-from-pdf'])): ?>
                                <label class="form-label fw-semibold small text-dark">Output Format</label>
                                <select class="form-select mb-3" id="formatSelect">
                                    <option value="docx" selected>DOCX (Microsoft Word 2007+)</option>
                                    <option value="rtf">RTF (Rich Text Format)</option>
                                </select>

                            <?php elseif(in_array($tool->slug, ['add-permissions', 'restrict-printing', 'restrict-copying', 'restrict-editing'])): ?>
                                <label class="form-label fw-semibold small text-dark">Security Password</label>
                                <input type="password" id="pdfPasswordInput" class="form-control mb-3" placeholder="Password to unlock permissions" value="restricted">

                            <?php elseif(in_array($tool->slug, ['sign-pdf', 'draw-signature', 'e-signature', 'draw-on-pdf', 'annotate-pdf', 'redact-pdf', 'highlight-pdf'])): ?>
                                <!-- Signature Pad & Annotation Canvas -->
                                <label class="form-label fw-semibold small text-dark">Draw Signature or Annotation</label>
                                
                                <div class="border rounded-3 p-2 bg-white mb-2 position-relative" style="max-width: 460px;">
                                    <canvas id="signatureCanvas" width="440" height="130" style="cursor: crosshair; touch-action: none; background: #fff; display: block;"></canvas>
                                    <div class="text-muted small position-absolute" style="bottom: 8px; right: 12px; font-size: 0.75rem;">Interactive Canvas Pad</div>
                                </div>
                                <button type="button" class="btn btn-sm btn-link text-decoration-none text-danger p-0 mb-3" onclick="clearSignatureCanvas()">
                                    <i class="bi bi-trash me-1"></i> Clear Drawing
                                </button>
                            <?php else: ?>
                                <div class="p-3 bg-light rounded-3 mb-3 border">
                                    <div class="d-flex align-items-center gap-2 text-dark fw-semibold small">
                                        <i class="bi bi-info-circle-fill text-primary"></i>
                                        <span>Ready to process with <?php echo e($tool->name); ?></span>
                                    </div>
                                    <p class="text-muted small mb-0 mt-1">Click the button below to process your document automatically.</p>
                                </div>
                            <?php endif; ?>

                            <!-- Action Buttons Matching Panels: Primary Action + Reset -->
                            <div class="d-flex gap-2 mt-2">
                                <button type="button" class="btn btn-pm-blue px-4 py-2" id="actionProcessBtn" onclick="submitToolProcess()">
                                    <i class="bi bi-gear-fill me-1"></i> <?php echo e($tool->name); ?>

                                </button>
                                <button type="button" class="btn btn-light border px-4 py-2 rounded-pill" onclick="resetFileSelection()">
                                    Reset
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Progress Loading Indicator -->
                    <div id="loadingStage" class="d-none text-center py-5">
                        <div class="spinner-border text-primary mb-3" role="status"></div>
                        <h5 class="fw-bold mb-1">Processing PDF...</h5>
                        <p class="text-muted small">Please wait while your document is processed.</p>
                    </div>

                    <!-- Success Download State -->
                    <div id="completedStage" class="d-none text-center py-4">
                        <div class="d-inline-flex p-3 rounded-circle bg-success bg-opacity-10 text-success mb-3">
                            <i class="bi bi-check-circle-fill display-5"></i>
                        </div>
                        <h4 class="fw-bold mb-1">Document Ready!</h4>
                        <p class="text-muted small mb-4" id="completedFilename">PDFMaster_Processed.pdf</p>

                        <div class="d-flex justify-content-center gap-3">
                            <a href="#" id="finalDownloadBtn" class="btn btn-success rounded-pill px-5 py-2 fw-bold">
                                <i class="bi bi-download me-1"></i> Download File
                            </a>
                            <button type="button" class="btn btn-outline-secondary rounded-pill px-4" onclick="resetFileSelection()">
                                Process Another
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Sidebar: Related Tools (30% Width) Matching Panels 3, 4, 5, 6 -->
            <div class="col-lg-4">
                <div class="card card-saas p-4">
                    <h6 class="fw-bold text-dark mb-3">Related Tools</h6>

                    <div class="d-flex flex-column gap-2">
                        <?php $__currentLoopData = $relatedTools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('tool.show', $rel->slug)); ?>" class="p-2 rounded-3 text-decoration-none d-flex align-items-center gap-3 border border-transparent hover-bg-light">
                            <div class="p-2 rounded-2 text-white" style="background-color: <?php echo e($rel->color); ?>; width: 34px; height: 34px; display: flex; align-items: center; justify-content: center;">
                                <i class="bi <?php echo e($rel->icon); ?> fs-6"></i>
                            </div>
                            <span class="small fw-semibold text-dark"><?php echo e($rel->name); ?></span>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- Auth Required Modal for Guests -->
<div class="modal fade" id="authRequiredModal" tabindex="-1" aria-labelledby="authRequiredModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 border-0 shadow-lg text-center p-4">
            <div class="d-inline-flex p-3 rounded-circle bg-primary bg-opacity-10 text-primary mx-auto mb-3" style="width: 70px; height: 70px; align-items: center; justify-content: center;">
                <i class="bi bi-shield-lock-fill fs-2"></i>
            </div>
            <h4 class="fw-extrabold text-dark mb-1" id="authRequiredModalLabel">Sign Up to Continue</h4>
            <p class="text-secondary small mb-4">
                To process <strong><?php echo e($tool->name); ?></strong>, please create an account or log in. Free accounts include 5 operations daily with instant access to 68+ PDF tools!
            </p>

            <div class="d-grid gap-2">
                <a href="<?php echo e(route('register')); ?>" class="btn btn-pm-blue py-2.5 fs-6 fw-bold">
                    <i class="bi bi-person-plus-fill me-1"></i> Create Free Account
                </a>
                <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-secondary py-2.5">
                    Already have an account? Log In
                </a>
            </div>

            <div class="text-muted small mt-3" style="font-size: 0.75rem;">
                <i class="bi bi-shield-check text-success me-1"></i> No credit card required to start • Upgrade anytime for higher limits
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    const isGuest = <?php echo json_encode(auth()->guest(), 15, 512) ?>;
    let guestOpsRemaining = <?php echo json_encode($guestOpsRemaining ?? 0, 15, 512) ?>;
    let authModalInstance = null;

    function getAuthModal() {
        if (!authModalInstance) {
            const el = document.getElementById('authRequiredModal');
            if (el) authModalInstance = new bootstrap.Modal(el);
        }
        return authModalInstance;
    }

    let currentFiles = [];
    const fileInput = document.getElementById('toolFileInput');
    const dropzoneStage = document.getElementById('dropzoneStage');
    const optionsStage = document.getElementById('optionsStage');
    const loadingStage = document.getElementById('loadingStage');
    const completedStage = document.getElementById('completedStage');

    fileInput.addEventListener('click', (e) => {
        if (isGuest && guestOpsRemaining <= 0) {
            e.preventDefault();
            getAuthModal()?.show();
            return false;
        }
    });

    fileInput.addEventListener('change', (e) => {
        if (isGuest && guestOpsRemaining <= 0) {
            e.preventDefault();
            fileInput.value = '';
            getAuthModal()?.show();
            return;
        }
        if (e.target.files.length > 0) {
            currentFiles = Array.from(e.target.files);
            showOptionsStage();
        }
    });

    function showOptionsStage() {
        dropzoneStage.classList.add('d-none');
        optionsStage.classList.remove('d-none');

        const f = currentFiles[0];
        document.getElementById('filePillName').textContent = currentFiles.length > 1 ? `${f.name} (+${currentFiles.length - 1} more)` : f.name;
        document.getElementById('filePillSize').textContent = (currentFiles.reduce((a,b)=>a+b.size,0) / 1048576).toFixed(2) + ' MB';

        const thumb = document.getElementById('imagePreviewThumb');
        const pdfIcon = document.getElementById('filePillPdfIcon');
        if (f && f.type.startsWith('image/')) {
            thumb.src = URL.createObjectURL(f);
            thumb.classList.remove('d-none');
            pdfIcon.classList.add('d-none');
        } else {
            thumb.classList.add('d-none');
            pdfIcon.classList.remove('d-none');
        }

        initSignature();
    }

    function resetFileSelection() {
        currentFiles = [];
        fileInput.value = '';
        dropzoneStage.classList.remove('d-none');
        optionsStage.classList.add('d-none');
        loadingStage.classList.add('d-none');
        completedStage.classList.add('d-none');
    }

    // Canvas Signature pad
    let sigCanvas, sCtx, drawing = false;
    function initSignature() {
        sigCanvas = document.getElementById('signatureCanvas');
        if (!sigCanvas) return;
        sCtx = sigCanvas.getContext('2d');
        sCtx.strokeStyle = '#0f172a';
        sCtx.lineWidth = 2.5;
        sCtx.lineCap = 'round';
        sigCanvas.onmousedown = (e) => { drawing = true; sCtx.beginPath(); sCtx.moveTo(e.offsetX, e.offsetY); };
        sigCanvas.onmousemove = (e) => { if (drawing) { sCtx.lineTo(e.offsetX, e.offsetY); sCtx.stroke(); } };
        window.onmouseup = () => { drawing = false; };
    }

    function clearSignatureCanvas() {
        if (sCtx && sigCanvas) sCtx.clearRect(0, 0, sigCanvas.width, sigCanvas.height);
    }

    async function submitToolProcess() {
        if (isGuest && guestOpsRemaining <= 0) {
            getAuthModal()?.show();
            return;
        }

        if (currentFiles.length === 0) {
            alert('Please select a file.');
            return;
        }

        const formData = new FormData();
        currentFiles.forEach(f => formData.append('files[]', f));

        // Compression level
        const comp = document.querySelector('input[name="compression_level"]:checked');
        if (comp) formData.append('compression_level', comp.value);

        // Rotation degrees
        const deg = document.querySelector('input[name="degrees"]:checked');
        if (deg) formData.append('degrees', deg.value);

        // Watermark text
        const wm = document.getElementById('watermarkTextInput');
        if (wm) formData.append('watermark_text', wm.value);

        // Page format
        const pFormat = document.getElementById('pageFormatSelect');
        if (pFormat) formData.append('page_format', pFormat.value);

        // Page range
        const pRange = document.getElementById('pageRangeInput');
        if (pRange) formData.append('page_range', pRange.value);

        // Pages to delete
        const pDelete = document.getElementById('pagesToDeleteInput');
        if (pDelete) formData.append('pages_to_delete', pDelete.value);

        // Page order
        const pOrder = document.getElementById('pageOrderInput');
        if (pOrder) formData.append('page_order', pOrder.value);

        // Duplicate pages
        const pDup = document.getElementById('duplicatePagesInput');
        if (pDup) formData.append('pages_to_duplicate', pDup.value);

        // Crop margin
        const cMargin = document.getElementById('cropMarginSelect');
        if (cMargin) formData.append('crop_margin', cMargin.value);

        // Text content & font size
        const addText = document.getElementById('addTextInput');
        if (addText) formData.append('text_content', addText.value);
        const fSize = document.getElementById('fontSizeSelect');
        if (fSize) formData.append('font_size', fSize.value);

        // Header & Footer
        const hText = document.getElementById('headerTextInput');
        if (hText) formData.append('header_text', hText.value);
        const fText = document.getElementById('footerTextInput');
        if (fText) formData.append('footer_text', fText.value);

        // Metadata
        const mTitle = document.getElementById('metaTitleInput');
        if (mTitle) formData.append('meta_title', mTitle.value);
        const mAuthor = document.getElementById('metaAuthorInput');
        if (mAuthor) formData.append('meta_author', mAuthor.value);
        const mSub = document.getElementById('metaSubjectInput');
        if (mSub) formData.append('meta_subject', mSub.value);
        const mKeys = document.getElementById('metaKeywordsInput');
        if (mKeys) formData.append('meta_keywords', mKeys.value);

        // Password
        const pwd = document.getElementById('pdfPasswordInput');
        if (pwd) formData.append('password', pwd.value);

        // Format
        const fmt = document.getElementById('formatSelect');
        if (fmt) formData.append('format', fmt.value);

        // Signature image
        if (sigCanvas) {
            formData.append('signature_image', sigCanvas.toDataURL('image/png'));
        }

        optionsStage.classList.add('d-none');
        loadingStage.classList.remove('d-none');

        try {
            const resp = await fetch("<?php echo e(route('tool.process', $tool->slug)); ?>", {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                    'Accept': 'application/json'
                },
                body: formData
            });

            const res = await resp.json();
            loadingStage.classList.add('d-none');

            if (resp.status === 401 || res.requires_auth) {
                optionsStage.classList.remove('d-none');
                getAuthModal()?.show();
                return;
            }

            if (res.success) {
                if (isGuest && guestOpsRemaining > 0) {
                    guestOpsRemaining--;
                }
                completedStage.classList.remove('d-none');
                document.getElementById('finalDownloadBtn').href = res.download_url;
                document.getElementById('completedFilename').textContent = `${res.filename} (${res.filesize})`;
            } else {
                alert(res.message || 'Operation failed.');
                optionsStage.classList.remove('d-none');
            }
        } catch (e) {
            loadingStage.classList.add('d-none');
            optionsStage.classList.remove('d-none');
            alert('Error processing document.');
        }
    }
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Websites\Dynamic Website\Laravel First Website\PDFMasster\.PDFMaster\resources\views/tools/show.blade.php ENDPATH**/ ?>